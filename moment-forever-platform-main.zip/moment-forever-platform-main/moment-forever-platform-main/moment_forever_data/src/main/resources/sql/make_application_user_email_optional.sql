-- Phone-only customers (no email address) can now sign up with just their
-- mobile number, so application_users.email becomes optional.
--
-- Hibernate's ddl-auto: update never drops a NOT NULL rule, so this has to be
-- run once on existing databases. SchemaPatchRunner (moment_forever_core) runs
-- it automatically on PostgreSQL at start-up unless app.schema-patches.enabled
-- is false. Safe to run more than once.
--
-- The unique rule on email stays: PostgreSQL allows many NULLs in a unique
-- column, so any number of phone-only customers can exist.

ALTER TABLE IF EXISTS application_users ALTER COLUMN email DROP NOT NULL;
