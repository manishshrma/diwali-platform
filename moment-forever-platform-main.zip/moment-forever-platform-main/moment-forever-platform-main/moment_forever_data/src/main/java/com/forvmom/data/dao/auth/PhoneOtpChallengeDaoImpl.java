package com.forvmom.data.dao.auth;

import com.forvmom.data.dao.GenericDaoImpl;
import com.forvmom.data.entities.auth.PhoneOtpChallenge;
import jakarta.persistence.LockModeType;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
@Transactional
public class PhoneOtpChallengeDaoImpl extends GenericDaoImpl<PhoneOtpChallenge, Long> implements PhoneOtpChallengeDao {

    public PhoneOtpChallengeDaoImpl() {
        super(PhoneOtpChallenge.class);
    }

    @Override
    public Optional<PhoneOtpChallenge> findLatestForUpdate(String phoneNumber, String purpose) {
        return em.createQuery(
                        "SELECT c FROM PhoneOtpChallenge c WHERE c.phoneNumber = :phone AND c.purpose = :purpose "
                                + "ORDER BY c.id DESC",
                        PhoneOtpChallenge.class)
                .setParameter("phone", phoneNumber)
                .setParameter("purpose", purpose)
                .setLockMode(LockModeType.PESSIMISTIC_WRITE)
                .setMaxResults(1)
                .getResultStream()
                .findFirst();
    }

    @Override
    public List<PhoneOtpChallenge> findPending(String phoneNumber, String purpose) {
        return em.createQuery(
                        "SELECT c FROM PhoneOtpChallenge c WHERE c.phoneNumber = :phone AND c.purpose = :purpose "
                                + "AND c.status = :pending",
                        PhoneOtpChallenge.class)
                .setParameter("phone", phoneNumber)
                .setParameter("purpose", purpose)
                .setParameter("pending", PhoneOtpChallenge.STATUS_PENDING)
                .getResultList();
    }

    @Override
    public long countCreatedSince(String phoneNumber, LocalDateTime since) {
        return em.createQuery(
                        "SELECT COUNT(c) FROM PhoneOtpChallenge c WHERE c.phoneNumber = :phone AND c.createdAt >= :since",
                        Long.class)
                .setParameter("phone", phoneNumber)
                .setParameter("since", since)
                .getSingleResult();
    }

    @Override
    public Optional<PhoneOtpChallenge> findBySignupTokenHashForUpdate(String signupTokenHash) {
        return em.createQuery(
                        "SELECT c FROM PhoneOtpChallenge c WHERE c.signupTokenHash = :hash",
                        PhoneOtpChallenge.class)
                .setParameter("hash", signupTokenHash)
                .setLockMode(LockModeType.PESSIMISTIC_WRITE)
                .setMaxResults(1)
                .getResultStream()
                .findFirst();
    }
}
