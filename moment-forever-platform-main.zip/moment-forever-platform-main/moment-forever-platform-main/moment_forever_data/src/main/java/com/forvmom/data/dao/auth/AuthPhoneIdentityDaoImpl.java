package com.forvmom.data.dao.auth;

import com.forvmom.data.dao.GenericDaoImpl;
import com.forvmom.data.entities.auth.AuthPhoneIdentity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Repository
@Transactional
public class AuthPhoneIdentityDaoImpl extends GenericDaoImpl<AuthPhoneIdentity, Long> implements AuthPhoneIdentityDao {

    public AuthPhoneIdentityDaoImpl() {
        super(AuthPhoneIdentity.class);
    }

    @Override
    public Optional<AuthPhoneIdentity> findByPhoneNumber(String phoneNumber) {
        return em.createQuery(
                        "SELECT pi FROM AuthPhoneIdentity pi JOIN FETCH pi.authUser WHERE pi.phoneNumber = :phone",
                        AuthPhoneIdentity.class)
                .setParameter("phone", phoneNumber)
                .getResultStream()
                .findFirst();
    }

    @Override
    public Optional<AuthPhoneIdentity> findByAuthUserId(Long authUserId) {
        return em.createQuery(
                        "SELECT pi FROM AuthPhoneIdentity pi WHERE pi.authUser.id = :authUserId ORDER BY pi.id DESC",
                        AuthPhoneIdentity.class)
                .setParameter("authUserId", authUserId)
                .setMaxResults(1)
                .getResultStream()
                .findFirst();
    }
}
