package com.forvmom.data.dao.auth;

import com.forvmom.data.dao.GenericDao;
import com.forvmom.data.entities.auth.AuthPhoneIdentity;

import java.util.Optional;

public interface AuthPhoneIdentityDao extends GenericDao<AuthPhoneIdentity, Long> {

    /** @param phoneNumber E.164 */
    Optional<AuthPhoneIdentity> findByPhoneNumber(String phoneNumber);

    Optional<AuthPhoneIdentity> findByAuthUserId(Long authUserId);
}
