package com.forvmom.data.entities.auth;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * A mobile number the customer PROVED they own (by entering the SMS code),
 * linked to their login account. Phone login only ever uses this table, never
 * the free-text {@code application_users.phone_number}, so typing someone
 * else's number into a profile can never give access to an account.
 *
 * <p>
 * Kept separate from {@link AuthIdentity} on purpose: adding a {@code PHONE}
 * value to that table's provider enum would need a database check-constraint
 * migration.
 */
@Entity
@Table(name = "auth_phone_identities",
        uniqueConstraints = @UniqueConstraint(name = "uq_auth_phone_identity_phone", columnNames = "phone_number"),
        indexes = @Index(name = "idx_auth_phone_identity_user", columnList = "auth_user_id"))
public class AuthPhoneIdentity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "auth_user_id", nullable = false)
    private AuthUser authUser;

    /** E.164, e.g. +919876543210. One account per number. */
    @Column(name = "phone_number", nullable = false, length = 20)
    private String phoneNumber;

    @Column(name = "verified_at", nullable = false)
    private LocalDateTime verifiedAt;

    @Column(name = "last_login_at")
    private LocalDateTime lastLoginAt;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public AuthUser getAuthUser() {
        return authUser;
    }

    public void setAuthUser(AuthUser authUser) {
        this.authUser = authUser;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public LocalDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(LocalDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public LocalDateTime getLastLoginAt() {
        return lastLoginAt;
    }

    public void setLastLoginAt(LocalDateTime lastLoginAt) {
        this.lastLoginAt = lastLoginAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
