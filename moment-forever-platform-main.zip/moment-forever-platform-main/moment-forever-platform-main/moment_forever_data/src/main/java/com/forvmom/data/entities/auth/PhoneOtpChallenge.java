package com.forvmom.data.entities.auth;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * One "we sent you a code" request. Only a keyed hash of the code is stored,
 * never the code itself.
 *
 * <p>
 * Status and purpose are plain text (not JPA enums) so new values never need a
 * database check-constraint migration.
 *
 * <pre>
 * PENDING ──right code──▶ VERIFIED ──account opened / phone linked──▶ CONSUMED
 *    │                        └── signup token unused for 15 min ──▶ (expired by time)
 *    ├── too many wrong codes ──▶ LOCKED
 *    └── newer code requested ──▶ SUPERSEDED
 * </pre>
 */
@Entity
@Table(name = "auth_phone_otp_challenges",
        indexes = {
                @Index(name = "idx_phone_otp_phone_created", columnList = "phone_number, created_at"),
                @Index(name = "idx_phone_otp_signup_token", columnList = "signup_token_hash")
        })
public class PhoneOtpChallenge {

    public static final String PURPOSE_LOGIN = "LOGIN";
    public static final String PURPOSE_LINK = "LINK";

    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_VERIFIED = "VERIFIED";
    public static final String STATUS_CONSUMED = "CONSUMED";
    public static final String STATUS_LOCKED = "LOCKED";
    public static final String STATUS_SUPERSEDED = "SUPERSEDED";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** E.164. */
    @Column(name = "phone_number", nullable = false, length = 20)
    private String phoneNumber;

    /** LOGIN (sign in / sign up) or LINK (add phone to a logged-in account). */
    @Column(name = "purpose", nullable = false, length = 10)
    private String purpose;

    /** For LINK: the application user who asked to link this phone. */
    @Column(name = "app_user_id")
    private Long appUserId;

    /** HMAC-SHA256 of the code (hex). */
    @Column(name = "otp_hash", nullable = false, length = 100)
    private String otpHash;

    @Column(name = "expires_at", nullable = false)
    private LocalDateTime expiresAt;

    @Column(name = "failed_attempts", nullable = false)
    private int failedAttempts;

    @Column(name = "status", nullable = false, length = 15)
    private String status;

    /** SHA-256 of the one-time token that lets a new customer finish sign-up. */
    @Column(name = "signup_token_hash", length = 100)
    private String signupTokenHash;

    @Column(name = "signup_token_expires_at")
    private LocalDateTime signupTokenExpiresAt;

    @Column(name = "verified_at")
    private LocalDateTime verifiedAt;

    @Column(name = "consumed_at")
    private LocalDateTime consumedAt;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Long getAppUserId() {
        return appUserId;
    }

    public void setAppUserId(Long appUserId) {
        this.appUserId = appUserId;
    }

    public String getOtpHash() {
        return otpHash;
    }

    public void setOtpHash(String otpHash) {
        this.otpHash = otpHash;
    }

    public LocalDateTime getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(LocalDateTime expiresAt) {
        this.expiresAt = expiresAt;
    }

    public int getFailedAttempts() {
        return failedAttempts;
    }

    public void setFailedAttempts(int failedAttempts) {
        this.failedAttempts = failedAttempts;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSignupTokenHash() {
        return signupTokenHash;
    }

    public void setSignupTokenHash(String signupTokenHash) {
        this.signupTokenHash = signupTokenHash;
    }

    public LocalDateTime getSignupTokenExpiresAt() {
        return signupTokenExpiresAt;
    }

    public void setSignupTokenExpiresAt(LocalDateTime signupTokenExpiresAt) {
        this.signupTokenExpiresAt = signupTokenExpiresAt;
    }

    public LocalDateTime getVerifiedAt() {
        return verifiedAt;
    }

    public void setVerifiedAt(LocalDateTime verifiedAt) {
        this.verifiedAt = verifiedAt;
    }

    public LocalDateTime getConsumedAt() {
        return consumedAt;
    }

    public void setConsumedAt(LocalDateTime consumedAt) {
        this.consumedAt = consumedAt;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
