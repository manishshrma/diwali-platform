package com.forvmom.data.dao.auth;

import com.forvmom.data.dao.GenericDao;
import com.forvmom.data.entities.auth.PhoneOtpChallenge;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PhoneOtpChallengeDao extends GenericDao<PhoneOtpChallenge, Long> {

    /** Newest challenge for this phone and purpose, locked for update. */
    Optional<PhoneOtpChallenge> findLatestForUpdate(String phoneNumber, String purpose);

    /** Open (PENDING) challenges for this phone and purpose. */
    List<PhoneOtpChallenge> findPending(String phoneNumber, String purpose);

    /** How many codes were sent to this phone since the given time (rate limit). */
    long countCreatedSince(String phoneNumber, LocalDateTime since);

    /** Challenge holding this sign-up token hash, locked for update. */
    Optional<PhoneOtpChallenge> findBySignupTokenHashForUpdate(String signupTokenHash);
}
