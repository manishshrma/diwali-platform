package com.forvmom.common.dto.response;

/**
 * Result of {@code POST /admin/experiences/{id}/clone}.
 *
 * <p>
 * {@code experience} is the new experience with its detail section, in the
 * same shape that create returns. Fetch {@code GET /admin/experiences/{id}}
 * with the new id for the full view (inclusions, policies, cities, gallery).
 * {@code copied} says how many linked rows were copied, so the admin portal
 * can confirm nothing was missed.
 */
public class ExperienceCloneResponseDto {

    private Long sourceExperienceId;

    private ExperienceResponseDto experience;

    private CopiedParts copied = new CopiedParts();

    public Long getSourceExperienceId() {
        return sourceExperienceId;
    }

    public void setSourceExperienceId(Long sourceExperienceId) {
        this.sourceExperienceId = sourceExperienceId;
    }

    public ExperienceResponseDto getExperience() {
        return experience;
    }

    public void setExperience(ExperienceResponseDto experience) {
        this.experience = experience;
    }

    public CopiedParts getCopied() {
        return copied;
    }

    public void setCopied(CopiedParts copied) {
        this.copied = copied;
    }

    /** Number of rows copied for each part of the experience. */
    public static class CopiedParts {

        private boolean detail;
        private int inclusions;
        private int cancellationPolicies;
        private int addons;
        private int coupons;
        private int media;
        private int locations;
        private int pincodes;
        private int timeSlots;

        public boolean isDetail() {
            return detail;
        }

        public void setDetail(boolean detail) {
            this.detail = detail;
        }

        public int getInclusions() {
            return inclusions;
        }

        public void setInclusions(int inclusions) {
            this.inclusions = inclusions;
        }

        public int getCancellationPolicies() {
            return cancellationPolicies;
        }

        public void setCancellationPolicies(int cancellationPolicies) {
            this.cancellationPolicies = cancellationPolicies;
        }

        public int getAddons() {
            return addons;
        }

        public void setAddons(int addons) {
            this.addons = addons;
        }

        public int getCoupons() {
            return coupons;
        }

        public void setCoupons(int coupons) {
            this.coupons = coupons;
        }

        public int getMedia() {
            return media;
        }

        public void setMedia(int media) {
            this.media = media;
        }

        public int getLocations() {
            return locations;
        }

        public void setLocations(int locations) {
            this.locations = locations;
        }

        public int getPincodes() {
            return pincodes;
        }

        public void setPincodes(int pincodes) {
            this.pincodes = pincodes;
        }

        public int getTimeSlots() {
            return timeSlots;
        }

        public void setTimeSlots(int timeSlots) {
            this.timeSlots = timeSlots;
        }
    }
}
