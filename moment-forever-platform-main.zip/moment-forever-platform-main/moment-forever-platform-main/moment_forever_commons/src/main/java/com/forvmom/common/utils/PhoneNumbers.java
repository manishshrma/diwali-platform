package com.forvmom.common.utils;

import java.util.Collection;

/**
 * Small, dependency-free helpers for mobile numbers in E.164 form
 * ({@code +<country code><number>}, e.g. {@code +919876543210}).
 *
 * <p>
 * Used by phone login (the verified number is the login identifier) and by the
 * booking snapshot (WhatsApp needs a real phone number, not an email).
 */
public final class PhoneNumbers {

    private PhoneNumbers() {
    }

    /**
     * Normalizes user input to E.164.
     * <ul>
     * <li>Spaces, dashes, dots and brackets are removed.</li>
     * <li>{@code 00} international prefix becomes {@code +}.</li>
     * <li>A national number without country code gets {@code defaultCountryCode}
     * (a leading trunk {@code 0} is dropped), e.g. {@code 09876543210} → {@code +919876543210}.</li>
     * </ul>
     *
     * @param raw                what the user typed
     * @param defaultCountryCode digits only, e.g. {@code "91"}
     * @return the E.164 number, or null when the input is not a plausible mobile number
     */
    public static String normalize(String raw, String defaultCountryCode) {
        if (raw == null) {
            return null;
        }
        String cleaned = raw.trim().replaceAll("[\\s().\\-]", "");
        if (cleaned.startsWith("00")) {
            cleaned = "+" + cleaned.substring(2);
        }
        String e164;
        if (cleaned.startsWith("+")) {
            e164 = cleaned;
        } else {
            if (!cleaned.matches("\\d+") || defaultCountryCode == null || !defaultCountryCode.matches("\\d{1,3}")) {
                return null;
            }
            String national = cleaned.startsWith("0") ? cleaned.substring(1) : cleaned;
            if (national.startsWith(defaultCountryCode) && national.length() > 10) {
                e164 = "+" + national; // already carries the country code, e.g. 919876543210
            } else {
                e164 = "+" + defaultCountryCode + national;
            }
        }
        if (!isE164(e164)) {
            return null;
        }
        // India: mobile numbers are exactly 10 digits starting 6-9.
        if (e164.startsWith("+91") && !e164.matches("\\+91[6-9]\\d{9}")) {
            return null;
        }
        return e164;
    }

    /** {@code +} followed by 8 to 15 digits, first digit not 0. */
    public static boolean isE164(String value) {
        return value != null && value.matches("\\+[1-9]\\d{7,14}");
    }

    /**
     * True when the E.164 number starts with one of the allowed country codes
     * (digits only, e.g. {@code "91"}). An empty collection allows every country.
     */
    public static boolean hasAllowedCountryCode(String e164, Collection<String> allowedCountryCodes) {
        if (!isE164(e164)) {
            return false;
        }
        if (allowedCountryCodes == null || allowedCountryCodes.isEmpty()) {
            return true;
        }
        return allowedCountryCodes.stream()
                .map(String::trim)
                .filter(code -> !code.isEmpty())
                .anyMatch(code -> e164.startsWith("+" + code));
    }

    /** For logs and responses: {@code +91******3210}. */
    public static String mask(String e164) {
        if (e164 == null || e164.length() < 7) {
            return "***";
        }
        int visibleEnd = 4;
        int visibleStart = Math.min(3, e164.length() - visibleEnd);
        return e164.substring(0, visibleStart)
                + "*".repeat(e164.length() - visibleStart - visibleEnd)
                + e164.substring(e164.length() - visibleEnd);
    }
}
