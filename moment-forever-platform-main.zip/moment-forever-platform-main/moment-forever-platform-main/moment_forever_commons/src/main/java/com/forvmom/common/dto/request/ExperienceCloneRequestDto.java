package com.forvmom.common.dto.request;

import jakarta.validation.constraints.Size;

/**
 * Optional settings for {@code POST /admin/experiences/{id}/clone}.
 *
 * <p>
 * Every field may be left out, and the whole body may be omitted:
 * <ul>
 * <li>{@code name} — defaults to the source name followed by " (Copy)".</li>
 * <li>{@code slug} — defaults to the source slug followed by "-copy",
 * "-copy-2", "-copy-3" … whichever is still free.</li>
 * <li>{@code subCategoryId} — defaults to the source experience's
 * sub-category.</li>
 * <li>{@code isActive} — defaults to {@code false}, so customers do not see
 * the copy until an admin has reviewed it.</li>
 * <li>{@code isFeatured} — defaults to {@code false}.</li>
 * </ul>
 */
public class ExperienceCloneRequestDto {

    @Size(max = 255, message = "Name must be at most 255 characters")
    private String name;

    @Size(max = 220, message = "Slug must be at most 220 characters")
    private String slug;

    private Long subCategoryId;

    private Boolean isActive = false;

    private Boolean isFeatured = false;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }

    public Long getSubCategoryId() {
        return subCategoryId;
    }

    public void setSubCategoryId(Long subCategoryId) {
        this.subCategoryId = subCategoryId;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Boolean getIsFeatured() {
        return isFeatured;
    }

    public void setIsFeatured(Boolean isFeatured) {
        this.isFeatured = isFeatured;
    }
}
