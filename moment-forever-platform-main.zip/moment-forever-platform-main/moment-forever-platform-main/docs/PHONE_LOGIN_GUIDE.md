# Phone Sign-in Guide (Mobile Number + SMS Code)

Customers can now sign in, or create an account, with their **mobile number**.
This works alongside the existing email/password and Google sign-in.

This guide explains it in plain English first, then how to switch it on with an
Indian SMS provider, and finally what code was written and where it lives.

---

## 1. In plain English

### What the customer sees

1. **Enter mobile number** → "We sent a 6-digit code to +91******3210".
2. **Enter the code.**
   - If this number already has an account → **they are signed in.**
   - If it is a new number → the app asks for their **name** (email is
     **optional**) once, then the account is created and they are signed in.

An existing customer (who signed up with email or Google) can **add their mobile
number** from their profile: they receive a code, enter it, and from then on can
sign in with that number too.

### The rules that keep it safe

| Rule | Why |
|---|---|
| The code has 6 digits and works for **5 minutes**. | Short enough that a stolen code is quickly useless. |
| **5 wrong tries** and the code stops working. | Nobody can guess their way in. |
| **30 seconds** between codes, **5 codes per hour** per number. | Limits SMS cost and guessing. |
| Only **Indian numbers (+91)** by default. | Blocks "SMS pumping" fraud, where bots make you pay for SMS to expensive foreign numbers. |
| We store only a **scrambled (hashed)** form of the code. | Even someone reading the database can't see codes. |
| The "send code" answer is **the same whether or not the number has an account**. | Nobody can use it to find out who our customers are. |
| A number signs in only to the account it was **proven** for (by entering a code). | Typing someone else's number into a profile never gives access. |
| If a new phone customer **does** type an email, it **cannot be one that already has an account.** | We can't prove the email is theirs, so the phone is never attached to someone else's account. They are asked to sign in that way and add the phone from their profile instead. |

### Customers without an email (phone-only)

Many customers, especially older ones, have no email address. They can still
sign up, sign in and book with just their mobile number:

| What | For a phone-only customer |
|---|---|
| Sign-up | Mobile number → code → name. The email box can be left empty. |
| Sign-in | Always by mobile number + code (they have no password). |
| Booking confirmed / cancelled | Sent as an **SMS** to their number, through the same SMS provider (see section 2). Customers who have an email keep getting email, not SMS. |
| WhatsApp booking messages | Same as everyone else (when WhatsApp is switched on). |
| Payment receipt (PDF) | Issued as normal. They download it in the app, or use "email it to me" and type any email address (for example a family member's). It is not sent by SMS. |
| Adding an email later | From their profile. It then also works as their email login id. |

Behind the scenes their account's login id is the mobile number itself (for
example `+919876543210`), and their profile simply has no email.

---

## 2. Choosing and switching on an SMS provider

The code is created and checked by **our own backend**. The SMS provider only
delivers it. Switching provider is a configuration change, not a code change.

| Provider | Best for | Notes |
|---|---|---|
| **2Factor** (recommended) | OTP-only, lowest cost, fastest start | Built for OTP. Can send with its own OTP template, so you can test before your own DLT approval (confirm production use with 2Factor). |
| **MSG91** | OTP + WhatsApp + email from one vendor | Very popular, good dashboard. Needs your own DLT-approved OTP template. Could also be the provider for WhatsApp booking messages. |
| **Exotel** | Businesses that also need calling / IVR | Mainly a telephony platform; plain OTP SMS usually costs more. Needs your DLT entity id and template id. |

Prices change often, so compare current per-SMS rates on each provider's pricing
page. For pure OTP traffic, 2Factor and MSG91 are typically the cheapest of the three.

**About DLT (India).** Every business SMS in India must be sent from a registered
business ("entity"), a registered sender name ("header", e.g. `MFOREV`) and a
registered message template. Register on a DLT portal (Jio, Airtel, Vodafone Idea,
etc.), then give the ids to your provider. The template must match the text
exactly, for example:
`{#var#} is your Moment Forever verification code. It expires in {#var#} minutes. Do not share it with anyone.`

### Settings (Platform)

| Environment variable | Meaning |
|---|---|
| `PHONE_SMS_PROVIDER` | `none` (default: phone sign-in **off**, answers 503), `log` (**local laptop only**: the code is printed in the log), `2factor`, `msg91`, `exotel` |
| `PHONE_OTP_SECRET` | Key used to scramble codes. Set a long random value (falls back to `jwt.secret`). |
| `TWOFACTOR_API_KEY` | 2Factor API key (required for `2factor`) |
| `TWOFACTOR_OTP_TEMPLATE` | Optional 2Factor template name (empty = 2Factor's default OTP template) |
| `MSG91_AUTH_KEY`, `MSG91_OTP_TEMPLATE_ID` | MSG91 auth key and DLT-approved OTP template id (both required for `msg91`) |
| `EXOTEL_API_KEY`, `EXOTEL_API_TOKEN`, `EXOTEL_SID` | Exotel credentials |
| `EXOTEL_SENDER_ID`, `EXOTEL_DLT_ENTITY_ID`, `EXOTEL_DLT_TEMPLATE_ID` | Exotel DLT sender and ids |
| `EXOTEL_SUBDOMAIN` | `api.exotel.com` (default) or `api.in.exotel.com` (Mumbai accounts) |

Limits (in `application.yml` under `auth.phone`): `default-country-code` (91),
`allowed-country-codes` (91), `otp-length` (6), `otp-ttl-seconds` (300),
`max-verify-attempts` (5), `resend-cooldown-seconds` (30), `max-sends-per-hour` (5),
`signup-token-ttl-minutes` (15). The Exotel message text is
`auth.phone.sms.message-template`.

If a provider is selected but its keys are missing, **Platform refuses to start**
with a clear message.

### Booking SMS for phone-only customers (Booking service)

Booking confirmations and cancellations go by SMS **only to customers without an
email**. It uses the same provider account as the sign-in codes, but each message
needs its own **DLT-approved template** with two variables, the booking reference
and the date. Suggested templates (register exactly this text):

- Confirmed: `Moment Forever: your booking {#var#} for {#var#} is confirmed. Thank you for booking with us.`
- Cancelled: `Moment Forever: your booking {#var#} for {#var#} has been cancelled. Contact us if you need help.`

Example SMS: *Moment Forever: your booking BK-1042 for 15 Jan 2030 is confirmed. Thank you for booking with us.*

| Environment variable (Booking) | Meaning |
|---|---|
| `BOOKING_SMS_NOTIFICATIONS_ENABLED` | `true` to send booking SMS (default `false`) |
| `BOOKING_SMS_PROVIDER` | `2factor` (recommended), `msg91`, `exotel`, or `log` (**local laptop only**: writes the text to the log) |
| `BOOKING_SMS_CONFIRMED_TEMPLATE`, `BOOKING_SMS_CANCELLED_TEMPLATE` | 2Factor: template **name**; MSG91: flow **template id**; Exotel: **DLT template id** |
| `TWOFACTOR_API_KEY`, `TWOFACTOR_SENDER_ID` | 2Factor key and your 6-letter DLT sender header |
| `MSG91_AUTH_KEY` | MSG91 auth key (the template variables are `var1`, `var2`) |
| `EXOTEL_API_KEY`, `EXOTEL_API_TOKEN`, `EXOTEL_SID`, `EXOTEL_SENDER_ID`, `EXOTEL_DLT_ENTITY_ID`, `EXOTEL_SUBDOMAIN` | Exotel, same values as Platform. With Exotel the message text is in `app.notifications.sms.confirmed.text` / `cancelled.text` and must match the DLT template word for word. |

Unlike sign-in, a missing Booking SMS setting **does not stop Booking from
starting**. A booking must never fail because of an SMS. The message is skipped
and an error naming the missing setting is logged. If the provider is down or
asks us to slow down, the message is retried automatically. If it refuses the
message (wrong template or key), it is logged and not retried, because retrying
cannot fix that.

Before going live, check the 2Factor transactional endpoint
(`/API/V1/{key}/ADDON_SERVICES/SEND/TSMS`) against the API page in your 2Factor
dashboard, and send yourself a test booking SMS.

### Going-live checklist

1. Pick a provider (2Factor recommended) and create the account.
2. Finish DLT registration (or confirm you can use 2Factor's template). Register
   the two booking templates above too.
3. Set `PHONE_SMS_PROVIDER` and the provider's variables, plus `PHONE_OTP_SECRET`,
   in the Platform secret.
4. Set the `BOOKING_SMS_*` variables and the provider's variables in the Booking secret.
5. Make sure the database changes ran (see "Database changes" in section 5). They
   run automatically on PostgreSQL at start-up.
6. Send yourself a code from the app, sign up **without an email**, book, and check
   the confirmation SMS.
7. Never use `log` outside a laptop.

---

## 3. API

All paths are behind the gateway as `/api/platform/...`. Responses use the usual
envelope `{ "code", "status", "msg", "response" }`; the examples below show the
`response` part.

### Sign in / sign up (public)

`POST /auth/phone/otp`
```json
{ "phoneNumber": "98765 43210" }
```
→ `200` `{ "phoneNumber": "+91******3210", "expiresInSeconds": 300, "resendAfterSeconds": 30 }`
Errors: `400` invalid number or country, `429` too soon / too many, `503` phone
sign-in off or SMS provider failed.

`POST /auth/phone/verify`
```json
{ "phoneNumber": "9876543210", "otp": "482913" }
```
→ existing customer: `{ "signupRequired": false, "phoneNumber": "...", "session": { "token": "...", "refreshToken": "...", ... } }`
(the same session shape as email or Google sign-in).
→ new number: `{ "signupRequired": true, "signupToken": "<one-time token>", "signupTokenExpiresInSeconds": 900, "phoneNumber": "..." }`
Errors: `400` wrong / expired / locked code (with "tries left").

`POST /auth/phone/signup`
```json
{ "signupToken": "<from verify>", "fullName": "Asha Rao", "email": "asha@example.com", "preferredCity": "Bengaluru" }
```
`email` and `preferredCity` are optional. A phone-only customer sends just:
```json
{ "signupToken": "<from verify>", "fullName": "Kamala Devi" }
```
→ `201` with the session (for a phone-only customer `session.email` is `null`).
Errors: `400` token expired/used or email not valid, `409` email already has an
account ("sign in with your email or Google, then add your mobile number from your
profile") or number already has an account.

### Add or change the mobile number (signed-in customer)

`POST /user/phone/otp` `{ "phoneNumber": "..." }` → same as above.
`POST /user/phone/verify` `{ "phoneNumber": "...", "otp": "..." }` → `{ "phoneNumber": "+91******3210", "linked": true }`.
`409` if the number belongs to another account. The number on the profile is
updated too (it is used for WhatsApp booking messages).

---

## 4. How it works (step by step)

```mermaid
sequenceDiagram
    participant App
    participant P as Platform
    participant DB as Platform DB
    participant SMS as SMS provider
    App->>P: POST /auth/phone/otp {phone}
    P->>DB: limits ok? cancel older code, save HASH of new code
    P->>SMS: deliver code
    SMS-->>App: SMS "482913 is your Moment Forever code"
    App->>P: POST /auth/phone/verify {phone, code}
    P->>DB: compare hash (count wrong tries, lock after 5)
    alt number linked to an account
        P-->>App: signed in (token + refresh token)
    else new number
        P->>DB: save HASH of one-time sign-up token (15 min)
        P-->>App: signupRequired + signupToken
        App->>P: POST /auth/phone/signup {token, name, email optional}
        P->>DB: create login + profile (role USER) + verified phone link
        P-->>App: signed in
    end
```

Code states: `PENDING` → `VERIFIED` → `CONSUMED`, or `LOCKED` (too many wrong
tries) or `SUPERSEDED` (a newer code was sent).

---

## 5. Implementation overview (what code was written)

### New database tables (created automatically by Hibernate, no migration)

| Table | Holds |
|---|---|
| `auth_phone_identities` | Verified number ↔ account (`phone_number` unique, E.164 like `+919876543210`). The only thing phone sign-in trusts. |
| `auth_phone_otp_challenges` | Each code sent: number, purpose (`LOGIN`/`LINK`), hashed code, expiry, wrong tries, status, hashed sign-up token. |

Phone links have their own table instead of reusing `auth_identities` (Google),
because adding a value to that table's provider enum would need a database
check-constraint migration.

### Classes

| Module | Class | Job |
|---|---|---|
| commons | `utils/PhoneNumbers` | Turns `98765 43210` / `09876543210` / `+91-98765-43210` into `+919876543210`; checks country; masks for logs. |
| data | `entities/auth/AuthPhoneIdentity`, `PhoneOtpChallenge` + `dao/auth/*Dao(Impl)` | The two tables and their queries (with row locks where two requests could race). |
| security | `service/PhoneOtpService` | Creates the code (secure random), stores an HMAC-SHA256 hash, sends it, enforces wait/limit/tries/expiry, checks it in constant time. |
| security | `service/PhoneAccountService` | After a correct code: sign in, start sign-up (one-time token), create the account, or link a number to a signed-in customer. |
| security | `service/PhoneAuthService` | Puts the steps together. Checks the code in its own transaction so a wrong try is always counted. |
| security | `controller/PhoneAuthController` | The five endpoints above. |
| security | `sms/SmsSender` + `TwoFactorSmsSender`, `Msg91SmsSender`, `ExotelSmsSender`, `LoggingSmsSender`, `NoSmsSender` | Delivery through the chosen provider (plain HTTPS, no vendor SDK). |
| security | `dto/PhoneAuthDtos` | Request and response bodies. |

Sessions are issued by the existing `AuthSessionService`, so phone sign-in returns
exactly the same token shape as email or Google sign-in, and the gateway and other
services need no change. New accounts get the `USER` role only.

### Phone-only customers (email optional)

| Where | Change |
|---|---|
| Platform `ApplicationUser` | `email` may be empty (still unique when present). |
| Platform `PhoneAccountService.completeSignup` | No email → login id (`auth_users.username`) is the E.164 number. If a **deleted** phone-only account still holds that id, it is renamed `+91…#deleted-<id>` to free it; an active one → `409`. |
| Platform profile edit (`UserProfileService`) and admin edit (`AdminUserService`) | A blank email keeps the current one (or none). A blank phone keeps the current number, so an edit form can't silently stop a customer's SMS. Adding an email also makes it the login id. |
| Platform `AuthSessionService` | `email` in the session is the profile email (`null` for phone-only). |
| Booking `Booking.userEmail` | May be empty. |
| Booking `SmsNotificationService` (new) | Sends the booking SMS through 2Factor, MSG91 or Exotel (plain HTTPS, no SDK). |
| Booking `LifecycleNotificationService` | Customer has an email → email. No email → SMS. WhatsApp is unchanged. |

### Database changes

Hibernate creates new tables and columns itself, but it never removes a "must not
be empty" rule from an existing column. So two one-line changes are applied by a
small start-up step, `SchemaPatchRunner` (Platform core and Booking). It only runs
on PostgreSQL, is safe to run on every start, and can be switched off with
`SCHEMA_PATCHES_ENABLED=false` if the database user may not change tables. In that
case a DBA runs the SQL by hand:

| Service | SQL file | Statement |
|---|---|---|
| Platform | `moment_forever_data/src/main/resources/sql/make_application_user_email_optional.sql` | `ALTER TABLE IF EXISTS application_users ALTER COLUMN email DROP NOT NULL;` |
| Booking | `src/main/resources/sql/make_booking_user_email_optional.sql` | `ALTER TABLE IF EXISTS bookings ALTER COLUMN user_email DROP NOT NULL;` |

If the change could not be applied, start-up logs an error naming the file. Until
it is applied, phone-only sign-up (Platform) or their bookings (Booking) fail.

### Tests

`PhoneOtpServiceTest` (normalising numbers, hash-only storage, wait, hourly limit,
lock after 5 tries, expiry, link codes tied to the user), `PhoneAccountServiceTest`
(sign-in, sign-up token, account creation with and without email, email already
used, deleted account's number and login id, linking and replacing a number),
`IndianSmsSendersTest` (the exact requests sent to 2Factor, MSG91 and Exotel, and
their error handling), `AdminUserServiceRoleGuardTest` (editing a phone-only
customer keeps their number; adding an email), `SchemaPatchRunnerTest`.

Booking: `SmsNotificationServiceTest` (exact requests to 2Factor, MSG91 and Exotel;
skipped when off, misconfigured or the number is invalid; refused vs retried;
SMS instead of email only for customers without an email),
`PaymentWindowIntegrationTest.phoneOnlyCustomerWithoutEmailCanBookPayAndBeConfirmed`
(booking without email → payment → confirmed event carries the phone),
`SchemaPatchRunnerTest`.

---

## 6. Not included yet

- **No limit per IP address**, only per number. Add one at the gateway if bots
  start requesting codes for many numbers.
- **No "remove my number"** endpoint; a number can be replaced, not unlinked.
- **Email is still not verified** at sign-up (open item S9 in
  `docs/runbook/08-known-limitations.md` at the workspace root).
- Phone-only customers have no password; they sign in by phone (or Google with the same email).
- **Payment receipts are not sent by SMS.** A phone-only customer downloads the
  receipt in the app or has it emailed to an address they type. Sending it by SMS
  would need a public receipt download link first (runbook item C7).
- If one channel fails temporarily (for example WhatsApp), the whole notification
  is retried, so the SMS can arrive twice. Email already behaves this way.
