package com.forvmom.security.controller;

import com.forvmom.common.errorhandler.CustomAuthException;
import com.forvmom.common.response.ApiResponse;
import com.forvmom.common.response.ResponseUtil;
import com.forvmom.security.dto.AuthResponse;
import com.forvmom.security.dto.JwtUserDetails;
import com.forvmom.security.dto.PhoneAuthDtos;
import com.forvmom.security.service.PhoneAuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Sign in with a mobile number and a one-time SMS code.
 *
 * <ul>
 * <li>{@code POST /auth/phone/otp} – send a code (public)</li>
 * <li>{@code POST /auth/phone/verify} – check the code: signs in an existing
 * customer, or returns a sign-up token for a new one (public)</li>
 * <li>{@code POST /auth/phone/signup} – new customer: name + email with the
 * sign-up token; opens the account and signs in (public)</li>
 * <li>{@code POST /user/phone/otp} and {@code /user/phone/verify} – a
 * logged-in customer adds or changes their mobile number</li>
 * </ul>
 */
@RestController
@Tag(name = "Phone Sign-in API", description = "Mobile number + SMS code sign-in, sign-up and phone linking")
public class PhoneAuthController {

    private final PhoneAuthService phoneAuthService;

    public PhoneAuthController(PhoneAuthService phoneAuthService) {
        this.phoneAuthService = phoneAuthService;
    }

    @PostMapping("/auth/phone/otp")
    @Operation(summary = "Send sign-in code", description = "Sends a 6-digit code by SMS. Same answer whether or not the number has an account.")
    public ResponseEntity<ApiResponse<PhoneAuthDtos.OtpSentResponse>> sendLoginCode(
            @Valid @RequestBody PhoneAuthDtos.OtpRequest request) {
        return ResponseEntity.ok(ResponseUtil.buildOkResponse(
                phoneAuthService.requestLoginCode(request.phoneNumber()), "Code sent"));
    }

    @PostMapping("/auth/phone/verify")
    @Operation(summary = "Verify sign-in code", description = "Signs in an existing customer, or returns signupRequired=true with a one-time signupToken")
    public ResponseEntity<ApiResponse<PhoneAuthDtos.VerifyResponse>> verifyLoginCode(
            @Valid @RequestBody PhoneAuthDtos.VerifyRequest request) {
        PhoneAuthDtos.VerifyResponse response = phoneAuthService.verifyLoginCode(request.phoneNumber(), request.otp());
        return ResponseEntity.ok(ResponseUtil.buildOkResponse(response,
                response.signupRequired() ? "Number verified. Complete sign-up." : "Phone sign-in successful"));
    }

    @PostMapping("/auth/phone/signup")
    @Operation(summary = "Complete phone sign-up", description = "New customer: name and email with the signupToken. Opens a USER account and signs in.")
    public ResponseEntity<ApiResponse<AuthResponse>> completeSignup(
            @Valid @RequestBody PhoneAuthDtos.SignupRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ResponseUtil.buildCreatedResponse(phoneAuthService.completeSignup(request), "Account created"));
    }

    @PostMapping("/user/phone/otp")
    @Operation(summary = "Send code to add/change mobile number", description = "Logged-in customer only")
    public ResponseEntity<ApiResponse<PhoneAuthDtos.OtpSentResponse>> sendLinkCode(
            @Valid @RequestBody PhoneAuthDtos.OtpRequest request) {
        return ResponseEntity.ok(ResponseUtil.buildOkResponse(
                phoneAuthService.requestLinkCode(currentUserId(), request.phoneNumber()), "Code sent"));
    }

    @PostMapping("/user/phone/verify")
    @Operation(summary = "Verify code and link mobile number", description = "Logged-in customer only. The number can then be used to sign in.")
    public ResponseEntity<ApiResponse<PhoneAuthDtos.LinkedResponse>> verifyLinkCode(
            @Valid @RequestBody PhoneAuthDtos.VerifyRequest request) {
        return ResponseEntity.ok(ResponseUtil.buildOkResponse(
                phoneAuthService.verifyLinkCode(currentUserId(), request.phoneNumber(), request.otp()),
                "Mobile number linked"));
    }

    private static Long currentUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof JwtUserDetails user) {
            return user.getId();
        }
        throw new CustomAuthException("No authenticated user", HttpStatus.UNAUTHORIZED);
    }
}
