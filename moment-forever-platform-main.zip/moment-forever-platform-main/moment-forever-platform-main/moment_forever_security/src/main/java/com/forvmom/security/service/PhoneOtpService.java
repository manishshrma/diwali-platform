package com.forvmom.security.service;

import com.forvmom.common.errorhandler.CustomAuthException;
import com.forvmom.common.utils.PhoneNumbers;
import com.forvmom.data.dao.auth.PhoneOtpChallengeDao;
import com.forvmom.data.entities.auth.PhoneOtpChallenge;
import com.forvmom.security.sms.SmsDeliveryException;
import com.forvmom.security.sms.SmsSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.List;
import java.util.Optional;

/**
 * Creates, sends and checks the one-time SMS codes used by phone login.
 *
 * <p>
 * Safety rules (all configurable under {@code auth.phone.*}):
 * <ul>
 * <li>6-digit code from a secure random generator, valid 5 minutes.</li>
 * <li>Only a keyed hash (HMAC-SHA256) of the code is stored; comparison is
 * constant-time.</li>
 * <li>5 wrong tries lock the code; asking for a new code cancels the old one.</li>
 * <li>At least 30 seconds between codes and at most 5 codes per hour per number
 * (limits SMS cost and guessing).</li>
 * <li>Only allowed countries (default India, +91) to block SMS-fraud traffic
 * to premium international numbers.</li>
 * </ul>
 */
@Service
public class PhoneOtpService {

    private static final Logger log = LoggerFactory.getLogger(PhoneOtpService.class);

    private final PhoneOtpChallengeDao challengeDao;
    private final SmsSender smsSender;
    private final SecureRandom random = new SecureRandom();
    private final byte[] hmacKey;
    private final String defaultCountryCode;
    private final List<String> allowedCountryCodes;
    private final int otpLength;
    private final Duration otpTtl;
    private final int maxVerifyAttempts;
    private final Duration resendCooldown;
    private final int maxSendsPerHour;

    public PhoneOtpService(
            PhoneOtpChallengeDao challengeDao,
            SmsSender smsSender,
            @Value("${auth.phone.otp-secret:}") String otpSecret,
            @Value("${jwt.secret:}") String jwtSecret,
            @Value("${auth.phone.default-country-code:91}") String defaultCountryCode,
            @Value("${auth.phone.allowed-country-codes:91}") String allowedCountryCodes,
            @Value("${auth.phone.otp-length:6}") int otpLength,
            @Value("${auth.phone.otp-ttl-seconds:300}") long otpTtlSeconds,
            @Value("${auth.phone.max-verify-attempts:5}") int maxVerifyAttempts,
            @Value("${auth.phone.resend-cooldown-seconds:30}") long resendCooldownSeconds,
            @Value("${auth.phone.max-sends-per-hour:5}") int maxSendsPerHour) {
        String secret = otpSecret != null && !otpSecret.isBlank() ? otpSecret : jwtSecret;
        if (secret == null || secret.isBlank()) {
            throw new IllegalStateException("auth.phone.otp-secret (or jwt.secret) must be set to hash OTP codes");
        }
        this.challengeDao = challengeDao;
        this.smsSender = smsSender;
        this.hmacKey = secret.getBytes(StandardCharsets.UTF_8);
        this.defaultCountryCode = defaultCountryCode;
        this.allowedCountryCodes = Arrays.stream(allowedCountryCodes == null ? new String[0] : allowedCountryCodes.split(","))
                .map(String::trim).filter(code -> !code.isEmpty()).toList();
        this.otpLength = Math.min(Math.max(otpLength, 4), 8);
        this.otpTtl = Duration.ofSeconds(Math.max(otpTtlSeconds, 60));
        this.maxVerifyAttempts = Math.max(maxVerifyAttempts, 1);
        this.resendCooldown = Duration.ofSeconds(Math.max(resendCooldownSeconds, 0));
        this.maxSendsPerHour = Math.max(maxSendsPerHour, 1);
    }

    /** Result of sending a code: what the app may show the customer. */
    public record OtpSent(String maskedPhone, long expiresInSeconds, long resendAfterSeconds) {
    }

    /**
     * Turns user input into E.164, or answers 400 with a message the app can show.
     */
    public String normalize(String rawPhone) {
        String e164 = PhoneNumbers.normalize(rawPhone, defaultCountryCode);
        if (e164 == null) {
            throw new CustomAuthException("Enter a valid mobile number", HttpStatus.BAD_REQUEST);
        }
        if (!PhoneNumbers.hasAllowedCountryCode(e164, allowedCountryCodes)) {
            throw new CustomAuthException("Phone sign-in is not available for this country", HttpStatus.BAD_REQUEST);
        }
        return e164;
    }

    /**
     * Creates a new code for this number and sends it by SMS. If the SMS cannot
     * be sent, nothing is saved (so the customer is not blocked by the resend
     * wait) and 503 is returned.
     *
     * @param appUserId for LINK: the logged-in user; null for LOGIN
     */
    @Transactional
    public OtpSent issue(String e164, String purpose, Long appUserId) {
        if (!smsSender.isAvailable()) {
            throw new CustomAuthException("Phone sign-in is not available right now. Please use email or Google.",
                    HttpStatus.SERVICE_UNAVAILABLE);
        }
        LocalDateTime now = LocalDateTime.now();
        // Locks the newest code for this number so two parallel requests cannot both pass the wait.
        Optional<PhoneOtpChallenge> latest = challengeDao.findLatestForUpdate(e164, purpose);
        if (latest.isPresent() && latest.get().getCreatedAt() != null) {
            LocalDateTime nextAllowed = latest.get().getCreatedAt().plus(resendCooldown);
            if (now.isBefore(nextAllowed)) {
                long waitSeconds = Math.max(1, Duration.between(now, nextAllowed).getSeconds());
                throw new CustomAuthException("Please wait " + waitSeconds + " seconds before asking for a new code",
                        HttpStatus.TOO_MANY_REQUESTS);
            }
        }
        if (challengeDao.countCreatedSince(e164, now.minusHours(1)) >= maxSendsPerHour) {
            throw new CustomAuthException("Too many codes requested for this number. Try again later.",
                    HttpStatus.TOO_MANY_REQUESTS);
        }
        for (PhoneOtpChallenge pending : challengeDao.findPending(e164, purpose)) {
            pending.setStatus(PhoneOtpChallenge.STATUS_SUPERSEDED);
            challengeDao.update(pending);
        }

        String code = newCode();
        PhoneOtpChallenge challenge = new PhoneOtpChallenge();
        challenge.setPhoneNumber(e164);
        challenge.setPurpose(purpose);
        challenge.setAppUserId(appUserId);
        challenge.setOtpHash(hashCode(e164, purpose, code));
        challenge.setExpiresAt(now.plus(otpTtl));
        challenge.setFailedAttempts(0);
        challenge.setStatus(PhoneOtpChallenge.STATUS_PENDING);
        challengeDao.save(challenge);

        try {
            smsSender.sendCode(e164, code, otpTtl.toMinutes());
        } catch (SmsDeliveryException e) {
            // Rolls back the new code (unchecked exception) so the customer can retry at once.
            throw new CustomAuthException("Could not send the code right now. Please try again.",
                    HttpStatus.SERVICE_UNAVAILABLE);
        }
        log.info("Phone code sent to {} for {}", PhoneNumbers.mask(e164), purpose);
        return new OtpSent(PhoneNumbers.mask(e164), otpTtl.getSeconds(), resendCooldown.getSeconds());
    }

    /**
     * Checks a code. Wrong tries are saved even though an error is returned
     * (noRollbackFor), otherwise guessing would be unlimited. Call this outside
     * any other transaction.
     *
     * @param appUserId for LINK: must be the user who asked for the code
     * @return the challenge, now VERIFIED
     */
    @Transactional(noRollbackFor = CustomAuthException.class)
    public PhoneOtpChallenge verify(String e164, String purpose, String code, Long appUserId) {
        PhoneOtpChallenge challenge = challengeDao.findLatestForUpdate(e164, purpose)
                .orElseThrow(() -> invalid("Ask for a code first"));
        if (!PhoneOtpChallenge.STATUS_PENDING.equals(challenge.getStatus())) {
            throw invalid(PhoneOtpChallenge.STATUS_LOCKED.equals(challenge.getStatus())
                    ? "Too many wrong tries. Ask for a new code."
                    : "This code is no longer valid. Ask for a new code.");
        }
        if (appUserId != null && !appUserId.equals(challenge.getAppUserId())) {
            throw invalid("This code is no longer valid. Ask for a new code.");
        }
        if (LocalDateTime.now().isAfter(challenge.getExpiresAt())) {
            throw invalid("This code has expired. Ask for a new code.");
        }
        String submitted = code == null ? "" : code.trim();
        boolean matches = submitted.matches("\\d{" + otpLength + "}")
                && MessageDigest.isEqual(
                        hashCode(e164, purpose, submitted).getBytes(StandardCharsets.UTF_8),
                        challenge.getOtpHash().getBytes(StandardCharsets.UTF_8));
        if (!matches) {
            int failed = challenge.getFailedAttempts() + 1;
            challenge.setFailedAttempts(failed);
            if (failed >= maxVerifyAttempts) {
                challenge.setStatus(PhoneOtpChallenge.STATUS_LOCKED);
            }
            challengeDao.update(challenge);
            log.info("Wrong phone code for {} ({}/{})", PhoneNumbers.mask(e164), failed, maxVerifyAttempts);
            throw invalid(failed >= maxVerifyAttempts
                    ? "Too many wrong tries. Ask for a new code."
                    : "Incorrect code. " + (maxVerifyAttempts - failed) + " tries left.");
        }
        challenge.setStatus(PhoneOtpChallenge.STATUS_VERIFIED);
        challenge.setVerifiedAt(LocalDateTime.now());
        challengeDao.update(challenge);
        return challenge;
    }

    String hashCode(String e164, String purpose, String code) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(hmacKey, "HmacSHA256"));
            byte[] digest = mac.doFinal((e164 + "|" + purpose + "|" + code).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            throw new IllegalStateException("Could not hash phone code", e);
        }
    }

    private String newCode() {
        int bound = (int) Math.pow(10, otpLength);
        return String.format("%0" + otpLength + "d", random.nextInt(bound));
    }

    private static CustomAuthException invalid(String message) {
        return new CustomAuthException(message, HttpStatus.BAD_REQUEST);
    }
}
