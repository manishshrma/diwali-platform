package com.forvmom.security.sms;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Default: no SMS provider configured, so phone login is switched off and the
 * API answers {@code 503}. Safe for any environment.
 */
@Component
@ConditionalOnProperty(name = "auth.phone.sms.provider", havingValue = "none", matchIfMissing = true)
public class NoSmsSender implements SmsSender {

    @Override
    public void sendCode(String e164Phone, String code, long validMinutes) {
        throw new SmsDeliveryException("No SMS provider is configured (auth.phone.sms.provider=none)");
    }

    @Override
    public boolean isAvailable() {
        return false;
    }
}
