package com.forvmom.security.sms;

import com.forvmom.common.utils.PhoneNumbers;
import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * LOCAL DEVELOPMENT ONLY: writes the code to the log instead of sending it.
 * Anyone who can read the logs could sign in as anyone, so never enable this in
 * a shared or production environment.
 */
@Component
@ConditionalOnProperty(name = "auth.phone.sms.provider", havingValue = "log")
public class LoggingSmsSender implements SmsSender {

    private static final Logger log = LoggerFactory.getLogger(LoggingSmsSender.class);

    @PostConstruct
    void warn() {
        log.warn("auth.phone.sms.provider=log: phone login codes are WRITTEN TO THE LOG. "
                + "Local development only - never use this in a shared or production environment.");
    }

    @Override
    public void sendCode(String e164Phone, String code, long validMinutes) {
        log.warn("[DEV SMS] code for {}: {} (valid {} min)", PhoneNumbers.mask(e164Phone), code, validMinutes);
    }
}
