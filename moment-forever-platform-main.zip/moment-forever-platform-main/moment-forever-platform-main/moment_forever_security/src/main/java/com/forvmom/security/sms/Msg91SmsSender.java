package com.forvmom.security.sms;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.forvmom.common.utils.PhoneNumbers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;

/**
 * MSG91 OTP SMS.
 *
 * <p>
 * Uses the Send OTP call with our own code:
 * {@code POST https://control.msg91.com/api/v5/otp?template_id=..&mobile=91XXXXXXXXXX&otp=..&otp_expiry=..}
 * with header {@code authkey}. MSG91 fills the code into your DLT-approved OTP
 * template. Success response: {@code {"type":"success","request_id":"..."}}.
 *
 * <p>
 * Settings: {@code MSG91_AUTH_KEY} and {@code MSG91_OTP_TEMPLATE_ID} (both required).
 */
@Component
@ConditionalOnProperty(name = "auth.phone.sms.provider", havingValue = "msg91")
public class Msg91SmsSender implements SmsSender {

    private static final Logger log = LoggerFactory.getLogger(Msg91SmsSender.class);

    private final String authKey;
    private final String templateId;
    private final String baseUrl;
    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public Msg91SmsSender(
            @Value("${auth.phone.sms.msg91.auth-key:}") String authKey,
            @Value("${auth.phone.sms.msg91.template-id:}") String templateId,
            @Value("${auth.phone.sms.msg91.base-url:https://control.msg91.com}") String baseUrl) {
        this(authKey, templateId, baseUrl, new RestTemplate());
    }

    Msg91SmsSender(String authKey, String templateId, String baseUrl, RestTemplate restTemplate) {
        if (authKey == null || authKey.isBlank() || templateId == null || templateId.isBlank()) {
            throw new IllegalStateException("auth.phone.sms.provider=msg91 needs MSG91_AUTH_KEY and MSG91_OTP_TEMPLATE_ID");
        }
        this.authKey = authKey;
        this.templateId = templateId;
        this.baseUrl = baseUrl;
        this.restTemplate = restTemplate;
    }

    @Override
    public void sendCode(String e164Phone, String code, long validMinutes) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
        headers.set("authkey", authKey);
        String body;
        try {
            body = restTemplate.postForObject(
                    baseUrl + "/api/v5/otp?template_id={templateId}&mobile={mobile}&otp={otp}&otp_expiry={expiry}",
                    new HttpEntity<>("{}", headers), String.class,
                    templateId, SmsSender.digitsOnly(e164Phone), code, validMinutes);
        } catch (RestClientException e) {
            log.warn("MSG91 SMS to {} failed: {}", PhoneNumbers.mask(e164Phone), e.getMessage());
            throw new SmsDeliveryException("MSG91 did not accept the message", e);
        }
        String type = field(body, "type");
        if (!"success".equalsIgnoreCase(type)) {
            log.warn("MSG91 refused SMS to {}: {}", PhoneNumbers.mask(e164Phone), field(body, "message"));
            throw new SmsDeliveryException("MSG91 refused the message: " + field(body, "message"));
        }
        log.info("SMS code sent via MSG91 to {}", PhoneNumbers.mask(e164Phone));
    }

    private String field(String json, String name) {
        try {
            JsonNode node = objectMapper.readTree(json == null ? "{}" : json).get(name);
            return node == null ? null : node.asText();
        } catch (Exception e) {
            return null;
        }
    }
}
