package com.forvmom.security.sms;

import com.forvmom.common.utils.PhoneNumbers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

/**
 * Exotel SMS.
 *
 * <p>
 * {@code POST https://<subdomain>/v1/Accounts/<sid>/Sms/send.json} with basic
 * auth (API key / API token) and form fields {@code From}, {@code To},
 * {@code Body}, {@code DltEntityId}, {@code DltTemplateId}, {@code SmsType}.
 * The body is our message template with the code filled in, and must match the
 * DLT-registered template exactly.
 *
 * <p>
 * Settings: {@code EXOTEL_API_KEY}, {@code EXOTEL_API_TOKEN}, {@code EXOTEL_SID},
 * {@code EXOTEL_SENDER_ID}, {@code EXOTEL_DLT_ENTITY_ID}, {@code EXOTEL_DLT_TEMPLATE_ID}
 * (all required); {@code EXOTEL_SUBDOMAIN} (default {@code api.exotel.com};
 * Mumbai cluster accounts use {@code api.in.exotel.com}).
 */
@Component
@ConditionalOnProperty(name = "auth.phone.sms.provider", havingValue = "exotel")
public class ExotelSmsSender implements SmsSender {

    private static final Logger log = LoggerFactory.getLogger(ExotelSmsSender.class);

    private final String apiKey;
    private final String apiToken;
    private final String sid;
    private final String subdomain;
    private final String senderId;
    private final String dltEntityId;
    private final String dltTemplateId;
    private final String messageTemplate;
    private final RestTemplate restTemplate;

    @Autowired
    public ExotelSmsSender(
            @Value("${auth.phone.sms.exotel.api-key:}") String apiKey,
            @Value("${auth.phone.sms.exotel.api-token:}") String apiToken,
            @Value("${auth.phone.sms.exotel.sid:}") String sid,
            @Value("${auth.phone.sms.exotel.subdomain:api.exotel.com}") String subdomain,
            @Value("${auth.phone.sms.exotel.sender-id:}") String senderId,
            @Value("${auth.phone.sms.exotel.dlt-entity-id:}") String dltEntityId,
            @Value("${auth.phone.sms.exotel.dlt-template-id:}") String dltTemplateId,
            @Value("${auth.phone.sms.message-template:{code} is your Moment Forever verification code. It expires in {minutes} minutes. Do not share it with anyone.}") String messageTemplate) {
        this(apiKey, apiToken, sid, subdomain, senderId, dltEntityId, dltTemplateId, messageTemplate, new RestTemplate());
    }

    ExotelSmsSender(String apiKey, String apiToken, String sid, String subdomain, String senderId,
                    String dltEntityId, String dltTemplateId, String messageTemplate, RestTemplate restTemplate) {
        if (isBlank(apiKey) || isBlank(apiToken) || isBlank(sid) || isBlank(senderId)
                || isBlank(dltEntityId) || isBlank(dltTemplateId)) {
            throw new IllegalStateException("auth.phone.sms.provider=exotel needs EXOTEL_API_KEY, EXOTEL_API_TOKEN, "
                    + "EXOTEL_SID, EXOTEL_SENDER_ID, EXOTEL_DLT_ENTITY_ID and EXOTEL_DLT_TEMPLATE_ID");
        }
        this.apiKey = apiKey;
        this.apiToken = apiToken;
        this.sid = sid;
        this.subdomain = isBlank(subdomain) ? "api.exotel.com" : subdomain.trim();
        this.senderId = senderId;
        this.dltEntityId = dltEntityId;
        this.dltTemplateId = dltTemplateId;
        this.messageTemplate = messageTemplate;
        this.restTemplate = restTemplate;
    }

    @Override
    public void sendCode(String e164Phone, String code, long validMinutes) {
        MultiValueMap<String, String> form = new LinkedMultiValueMap<>();
        form.add("From", senderId);
        form.add("To", e164Phone);
        form.add("Body", SmsSender.render(messageTemplate, code, validMinutes));
        form.add("DltEntityId", dltEntityId);
        form.add("DltTemplateId", dltTemplateId);
        form.add("SmsType", "transactional");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.setBasicAuth(apiKey, apiToken);
        try {
            restTemplate.postForEntity("https://" + subdomain + "/v1/Accounts/{sid}/Sms/send.json",
                    new HttpEntity<>(form, headers), String.class, sid);
        } catch (RestClientException e) {
            log.warn("Exotel SMS to {} failed: {}", PhoneNumbers.mask(e164Phone), e.getMessage());
            throw new SmsDeliveryException("Exotel did not accept the message", e);
        }
        log.info("SMS code sent via Exotel to {}", PhoneNumbers.mask(e164Phone));
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
