package com.forvmom.security.service;

import com.forvmom.common.errorhandler.ConflictException;
import com.forvmom.common.errorhandler.CustomAuthException;
import com.forvmom.common.errorhandler.ResourceNotFoundException;
import com.forvmom.common.utils.PhoneNumbers;
import com.forvmom.data.dao.ApplicationUserDao;
import com.forvmom.data.dao.auth.AuthPhoneIdentityDao;
import com.forvmom.data.dao.auth.AuthUserDao;
import com.forvmom.data.dao.auth.PhoneOtpChallengeDao;
import com.forvmom.data.dao.auth.RoleDao;
import com.forvmom.data.entities.ApplicationUser;
import com.forvmom.data.entities.auth.AuthPhoneIdentity;
import com.forvmom.data.entities.auth.AuthUser;
import com.forvmom.data.entities.auth.PhoneOtpChallenge;
import com.forvmom.data.entities.auth.Role;
import com.forvmom.security.dto.AuthResponse;
import com.forvmom.security.dto.PhoneAuthDtos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HexFormat;
import java.util.Optional;
import java.util.UUID;

/**
 * Account side of phone sign-in, after the SMS code was verified: sign in an
 * existing customer, open a new account, or link a phone to a logged-in
 * account. Each public method is one database transaction.
 *
 * <p>
 * Phone sign-in only trusts {@link AuthPhoneIdentity} (numbers proven by SMS),
 * never the free-text phone on a profile, and never links a phone to an
 * existing account by email (email ownership is not verified), so a phone code
 * can only ever open the account that number was proven for.
 */
@Service
public class PhoneAccountService {

    private static final Logger log = LoggerFactory.getLogger(PhoneAccountService.class);

    static final String CUSTOMER_ROLE = "USER";

    private final PhoneOtpChallengeDao challengeDao;
    private final AuthPhoneIdentityDao phoneIdentityDao;
    private final AuthUserDao authUserDao;
    private final ApplicationUserDao applicationUserDao;
    private final RoleDao roleDao;
    private final PasswordEncoder passwordEncoder;
    private final AuthService authService;
    private final AuthSessionService authSessionService;
    private final long signupTokenTtlMinutes;
    private final SecureRandom random = new SecureRandom();

    public PhoneAccountService(PhoneOtpChallengeDao challengeDao,
                               AuthPhoneIdentityDao phoneIdentityDao,
                               AuthUserDao authUserDao,
                               ApplicationUserDao applicationUserDao,
                               RoleDao roleDao,
                               PasswordEncoder passwordEncoder,
                               AuthService authService,
                               AuthSessionService authSessionService,
                               @Value("${auth.phone.signup-token-ttl-minutes:15}") long signupTokenTtlMinutes) {
        this.challengeDao = challengeDao;
        this.phoneIdentityDao = phoneIdentityDao;
        this.authUserDao = authUserDao;
        this.applicationUserDao = applicationUserDao;
        this.roleDao = roleDao;
        this.passwordEncoder = passwordEncoder;
        this.authService = authService;
        this.authSessionService = authSessionService;
        this.signupTokenTtlMinutes = Math.max(signupTokenTtlMinutes, 1);
    }

    /**
     * The code was right. If this number belongs to an account, sign in;
     * otherwise hand out a one-time token so the app can ask for a name (and,
     * optionally, an email).
     */
    @Transactional
    public PhoneAuthDtos.VerifyResponse loginOrStartSignup(Long challengeId, String e164) {
        PhoneOtpChallenge challenge = loadVerified(challengeId);
        Optional<AuthPhoneIdentity> identity = phoneIdentityDao.findByPhoneNumber(e164);
        if (identity.isPresent() && identity.get().getAuthUser().isDeleted()) {
            // The account this number belonged to was deleted; the number is free again.
            phoneIdentityDao.delete(identity.get());
            identity = Optional.empty();
        }
        if (identity.isPresent()) {
            AuthUser authUser = identity.get().getAuthUser();
            authService.assertAccountEligibleForLogin(authUser, PhoneNumbers.mask(e164));
            ApplicationUser appUser = applicationUserDao.findByAuthUserId(authUser.getId())
                    .orElseThrow(() -> new CustomAuthException("Account profile is missing. Please contact support.",
                            HttpStatus.UNAUTHORIZED));
            identity.get().setLastLoginAt(LocalDateTime.now());
            phoneIdentityDao.update(identity.get());
            consume(challenge);
            log.info("Phone sign-in for {}", PhoneNumbers.mask(e164));
            return PhoneAuthDtos.VerifyResponse.loggedIn(
                    authSessionService.createAuthenticatedSession(authUser, appUser, "Phone sign-in successful"),
                    PhoneNumbers.mask(e164));
        }

        String token = newToken();
        challenge.setSignupTokenHash(sha256(token));
        challenge.setSignupTokenExpiresAt(LocalDateTime.now().plusMinutes(signupTokenTtlMinutes));
        challengeDao.update(challenge);
        return PhoneAuthDtos.VerifyResponse.signupNeeded(token, signupTokenTtlMinutes * 60, PhoneNumbers.mask(e164));
    }

    /**
     * New customer: opens the account (role USER) for the verified number and
     * signs them in.
     *
     * <p>
     * Email is optional. Without one, the account's login id is the mobile
     * number itself and booking messages go by SMS. If an email is given it must
     * not belong to any account, including a deleted one: we cannot prove the
     * email is theirs, so we never attach a phone to someone else's account.
     */
    @Transactional
    public AuthResponse completeSignup(PhoneAuthDtos.SignupRequest request) {
        PhoneOtpChallenge challenge = challengeDao.findBySignupTokenHashForUpdate(sha256(request.signupToken()))
                .orElseThrow(() -> new CustomAuthException(
                        "Your sign-up session has expired. Verify your number again.", HttpStatus.BAD_REQUEST));
        if (!PhoneOtpChallenge.STATUS_VERIFIED.equals(challenge.getStatus())
                || challenge.getSignupTokenExpiresAt() == null
                || LocalDateTime.now().isAfter(challenge.getSignupTokenExpiresAt())) {
            throw new CustomAuthException("Your sign-up session has expired. Verify your number again.",
                    HttpStatus.BAD_REQUEST);
        }
        String e164 = challenge.getPhoneNumber();
        if (phoneIdentityDao.findByPhoneNumber(e164).isPresent()) {
            throw new ConflictException("This mobile number already has an account. Sign in with it instead.");
        }
        String email = blankToNull(request.email()) == null ? null : request.email().trim().toLowerCase();
        if (email != null && (applicationUserDao.findByEmailIgnoreCaseIncludingDeleted(email).isPresent()
                || authUserDao.findByUsernameIncludingDeleted(email).isPresent())) {
            throw new ConflictException("An account with this email already exists. Sign in with your email "
                    + "or Google, then add your mobile number from your profile.");
        }
        // Login id: the email, or for phone-only customers the verified number.
        String username = email != null ? email : e164;
        if (email == null) {
            freePhoneUsername(e164);
        }
        Role customerRole = roleDao.findByNameIgnoreCase(CUSTOMER_ROLE)
                .orElseThrow(() -> new ResourceNotFoundException("Role 'USER' not initialized in system"));

        AuthUser authUser = new AuthUser();
        authUser.setUsername(username);
        // Phone customers have no password; a random one keeps the column valid
        // and cannot be guessed (same approach as Google sign-in accounts).
        authUser.setPassword(passwordEncoder.encode("Phone-" + UUID.randomUUID() + "-Aa1!"));
        authUser.setEnabled(true);
        authUser.setAccountNonExpired(true);
        authUser.setAccountNonLocked(true);
        authUser.setCredentialsNonExpired(true);
        authUser.addRole(customerRole);
        AuthUser savedAuthUser = authUserDao.save(authUser);

        ApplicationUser appUser = new ApplicationUser();
        appUser.setAuthUser(savedAuthUser);
        appUser.setEmail(email);
        appUser.setFullName(request.fullName().trim());
        appUser.setPhoneNumber(e164);
        appUser.setPreferredCity(blankToNull(request.preferredCity()));
        appUser.setActive(true);
        ApplicationUser savedAppUser = applicationUserDao.save(appUser);

        AuthPhoneIdentity identity = new AuthPhoneIdentity();
        identity.setAuthUser(savedAuthUser);
        identity.setPhoneNumber(e164);
        identity.setVerifiedAt(challenge.getVerifiedAt() != null ? challenge.getVerifiedAt() : LocalDateTime.now());
        identity.setLastLoginAt(LocalDateTime.now());
        phoneIdentityDao.save(identity);

        consume(challenge);
        log.info("New customer account opened with phone {}", PhoneNumbers.mask(e164));
        return authSessionService.createAuthenticatedSession(savedAuthUser, savedAppUser, "Account created");
    }

    /**
     * Logged-in customer proved this number: link it to their account (or
     * replace their previous number). A number already linked to another
     * active account is refused.
     */
    @Transactional
    public PhoneAuthDtos.LinkedResponse linkPhone(Long challengeId, String e164, Long appUserId) {
        PhoneOtpChallenge challenge = loadVerified(challengeId);
        ApplicationUser appUser = resolveAppUser(appUserId);
        AuthUser authUser = appUser.getAuthUser();

        Optional<AuthPhoneIdentity> owner = phoneIdentityDao.findByPhoneNumber(e164);
        if (owner.isPresent()) {
            AuthUser ownerUser = owner.get().getAuthUser();
            if (ownerUser.getId().equals(authUser.getId())) {
                consume(challenge);
                return new PhoneAuthDtos.LinkedResponse(PhoneNumbers.mask(e164), true);
            }
            if (!ownerUser.isDeleted()) {
                throw new ConflictException("This mobile number is already linked to another account.");
            }
            phoneIdentityDao.delete(owner.get());
        }

        Optional<AuthPhoneIdentity> current = phoneIdentityDao.findByAuthUserId(authUser.getId());
        AuthPhoneIdentity identity = current.orElseGet(AuthPhoneIdentity::new);
        identity.setAuthUser(authUser);
        identity.setPhoneNumber(e164);
        identity.setVerifiedAt(LocalDateTime.now());
        if (current.isPresent()) {
            phoneIdentityDao.update(identity);
        } else {
            phoneIdentityDao.save(identity);
        }
        appUser.setPhoneNumber(e164);
        applicationUserDao.update(appUser);
        consume(challenge);
        log.info("Phone {} linked to app user {}", PhoneNumbers.mask(e164), appUser.getId());
        return new PhoneAuthDtos.LinkedResponse(PhoneNumbers.mask(e164), true);
    }

    /**
     * The logged-in caller's profile. The gateway forwards the application-user
     * id; older tokens carried the auth-user id, so both are accepted.
     */
    @Transactional(readOnly = true)
    public ApplicationUser resolveAppUser(Long principalId) {
        if (principalId == null) {
            throw new CustomAuthException("No authenticated user", HttpStatus.UNAUTHORIZED);
        }
        ApplicationUser byAppId = applicationUserDao.findById(principalId);
        if (byAppId != null) {
            return byAppId;
        }
        return applicationUserDao.findByAuthUserId(principalId)
                .orElseThrow(() -> new ResourceNotFoundException("User doesn't exist in System"));
    }

    /**
     * A phone-only account uses the number as its login id. If a DELETED
     * phone-only account still holds that id, rename it so the number can open a
     * new account; an active holder is refused.
     */
    private void freePhoneUsername(String e164) {
        Optional<AuthUser> holder = authUserDao.findByUsernameIncludingDeleted(e164);
        if (holder.isEmpty()) {
            return;
        }
        if (!holder.get().isDeleted()) {
            throw new ConflictException("This mobile number already has an account. Sign in with it instead.");
        }
        holder.get().setUsername(e164 + "#deleted-" + holder.get().getId());
        authUserDao.update(holder.get());
    }

    private PhoneOtpChallenge loadVerified(Long challengeId) {
        PhoneOtpChallenge challenge = challengeDao.findById(challengeId);
        if (challenge == null || !PhoneOtpChallenge.STATUS_VERIFIED.equals(challenge.getStatus())) {
            throw new CustomAuthException("This code is no longer valid. Ask for a new code.", HttpStatus.BAD_REQUEST);
        }
        return challenge;
    }

    private void consume(PhoneOtpChallenge challenge) {
        challenge.setStatus(PhoneOtpChallenge.STATUS_CONSUMED);
        challenge.setConsumedAt(LocalDateTime.now());
        challenge.setSignupTokenHash(null);
        challengeDao.update(challenge);
    }

    private String newToken() {
        byte[] bytes = new byte[32];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    static String sha256(String value) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 unavailable", e);
        }
    }

    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
