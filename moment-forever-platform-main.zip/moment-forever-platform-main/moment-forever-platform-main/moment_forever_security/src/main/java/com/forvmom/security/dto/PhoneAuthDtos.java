package com.forvmom.security.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/** Request and response bodies for phone sign-in. */
public final class PhoneAuthDtos {

    private PhoneAuthDtos() {
    }

    /** Step 1: "send me a code". */
    public record OtpRequest(
            @NotBlank(message = "Mobile number is required")
            @Size(max = 25, message = "Mobile number is too long")
            String phoneNumber) {
    }

    /** Step 2: "here is the code". */
    public record VerifyRequest(
            @NotBlank(message = "Mobile number is required")
            @Size(max = 25, message = "Mobile number is too long")
            String phoneNumber,
            @NotBlank(message = "Code is required")
            @Size(max = 10, message = "Code is too long")
            String otp) {
    }

    /**
     * Step 3 (new customers only): name, and optionally email, to open the
     * account. Without an email the customer gets booking messages by SMS.
     */
    public record SignupRequest(
            @NotBlank(message = "Sign-up token is required")
            String signupToken,
            @NotBlank(message = "Full name is required")
            @Size(max = 100, message = "Full name is too long")
            String fullName,
            @Email(message = "Valid email is required")
            @Size(max = 150, message = "Email is too long")
            String email,
            @Size(max = 50, message = "City is too long")
            String preferredCity) {
    }

    /** Answer to step 1. */
    public record OtpSentResponse(String phoneNumber, long expiresInSeconds, long resendAfterSeconds) {
    }

    /**
     * Answer to step 2: either a logged-in session ({@code signupRequired=false},
     * {@code session} set) or a one-time {@code signupToken} for step 3.
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public record VerifyResponse(boolean signupRequired, String signupToken, Long signupTokenExpiresInSeconds,
                                 String phoneNumber, AuthResponse session) {

        public static VerifyResponse loggedIn(AuthResponse session, String maskedPhone) {
            return new VerifyResponse(false, null, null, maskedPhone, session);
        }

        public static VerifyResponse signupNeeded(String token, long expiresInSeconds, String maskedPhone) {
            return new VerifyResponse(true, token, expiresInSeconds, maskedPhone, null);
        }
    }

    /** Answer after linking a phone to a logged-in account. */
    public record LinkedResponse(String phoneNumber, boolean linked) {
    }
}
