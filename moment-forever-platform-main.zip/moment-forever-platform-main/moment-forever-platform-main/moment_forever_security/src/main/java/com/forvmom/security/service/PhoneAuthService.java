package com.forvmom.security.service;

import com.forvmom.data.entities.ApplicationUser;
import com.forvmom.data.entities.auth.PhoneOtpChallenge;
import com.forvmom.security.dto.AuthResponse;
import com.forvmom.security.dto.PhoneAuthDtos;
import org.springframework.stereotype.Service;

/**
 * Phone sign-in, step by step. Deliberately NOT transactional: the code check
 * ({@link PhoneOtpService#verify}) commits on its own so a wrong guess is always
 * counted, then the account work runs in its own transaction
 * ({@link PhoneAccountService}).
 *
 * <pre>
 * 1. requestLoginCode(phone)            → SMS with a 6-digit code
 * 2. verifyLoginCode(phone, code)       → signed in, or a sign-up token for new customers
 * 3. completeSignup(token, name, email) → account opened and signed in
 * </pre>
 */
@Service
public class PhoneAuthService {

    private final PhoneOtpService otpService;
    private final PhoneAccountService accountService;

    public PhoneAuthService(PhoneOtpService otpService, PhoneAccountService accountService) {
        this.otpService = otpService;
        this.accountService = accountService;
    }

    /**
     * Sends a code. The answer is the same whether or not the number has an
     * account, so nobody can use this to find out who our customers are.
     */
    public PhoneAuthDtos.OtpSentResponse requestLoginCode(String rawPhone) {
        String e164 = otpService.normalize(rawPhone);
        return toResponse(otpService.issue(e164, PhoneOtpChallenge.PURPOSE_LOGIN, null));
    }

    public PhoneAuthDtos.VerifyResponse verifyLoginCode(String rawPhone, String code) {
        String e164 = otpService.normalize(rawPhone);
        PhoneOtpChallenge challenge = otpService.verify(e164, PhoneOtpChallenge.PURPOSE_LOGIN, code, null);
        return accountService.loginOrStartSignup(challenge.getId(), e164);
    }

    public AuthResponse completeSignup(PhoneAuthDtos.SignupRequest request) {
        return accountService.completeSignup(request);
    }

    /** Logged-in customer adds (or changes) their mobile number. */
    public PhoneAuthDtos.OtpSentResponse requestLinkCode(Long principalId, String rawPhone) {
        ApplicationUser appUser = accountService.resolveAppUser(principalId);
        String e164 = otpService.normalize(rawPhone);
        return toResponse(otpService.issue(e164, PhoneOtpChallenge.PURPOSE_LINK, appUser.getId()));
    }

    public PhoneAuthDtos.LinkedResponse verifyLinkCode(Long principalId, String rawPhone, String code) {
        ApplicationUser appUser = accountService.resolveAppUser(principalId);
        String e164 = otpService.normalize(rawPhone);
        PhoneOtpChallenge challenge = otpService.verify(e164, PhoneOtpChallenge.PURPOSE_LINK, code, appUser.getId());
        return accountService.linkPhone(challenge.getId(), e164, appUser.getId());
    }

    private static PhoneAuthDtos.OtpSentResponse toResponse(PhoneOtpService.OtpSent sent) {
        return new PhoneAuthDtos.OtpSentResponse(sent.maskedPhone(), sent.expiresInSeconds(), sent.resendAfterSeconds());
    }
}
