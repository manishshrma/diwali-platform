package com.forvmom.security.jwt_exception_handler;

import com.forvmom.common.response.ApiResponse;
import com.forvmom.common.response.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * Turns method-security denials ({@code @PreAuthorize} and friends) into
 * {@code 403 Forbidden}.
 *
 * <p>
 * Those denials are thrown inside the controller call, so they reach the
 * {@code @RestControllerAdvice} chain before Spring Security's
 * {@link JwtAccessDeniedHandler}. Without this advice the catch-all
 * {@code Exception} handler in {@code GlobalExceptionHandler} answered them
 * with {@code 500}. It must run first, hence the highest precedence.
 */
@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
public class MethodSecurityExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(MethodSecurityExceptionHandler.class);

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiResponse<Void>> handleAccessDenied(AccessDeniedException ex) {
        log.warn("Access denied by method security: {}", ex.getMessage());
        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(ResponseUtil.buildErrorResponse(
                        "Forbidden - you do not have permission to perform this action",
                        HttpStatus.FORBIDDEN));
    }
}
