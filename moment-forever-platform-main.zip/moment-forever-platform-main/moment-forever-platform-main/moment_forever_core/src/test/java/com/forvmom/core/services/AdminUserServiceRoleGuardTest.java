package com.forvmom.core.services;

import com.forvmom.common.dto.request.UserProfileRequestDto;
import com.forvmom.common.dto.response.AdminAppUserResponseDto;
import com.forvmom.common.errorhandler.NotAllowedCustomException;
import com.forvmom.data.dao.ApplicationUserDao;
import com.forvmom.data.dao.auth.AuthUserDao;
import com.forvmom.data.dao.auth.RefreshTokenDao;
import com.forvmom.data.dao.auth.RoleDao;
import com.forvmom.data.entities.ApplicationUser;
import com.forvmom.data.entities.auth.AuthUser;
import com.forvmom.data.entities.auth.AuthUserRole;
import com.forvmom.data.entities.auth.Role;
import com.forvmom.security.service.AuthService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * S1: an ADMIN must not be able to grant roles (e.g. promote itself to
 * SUPER_ADMIN) or edit/delete a SUPER_ADMIN account.
 */
class AdminUserServiceRoleGuardTest {

    private static final Long TARGET_ID = 42L;

    private ApplicationUserDao applicationUserDao;
    private AuthUserDao authUserDao;
    private RoleDao roleDao;
    private AdminUserService service;

    private final Role superAdminRole = role(1L, "SUPER_ADMIN");
    private final Role adminRole = role(2L, "ADMIN");
    private final Role userRole = role(10L, "USER");

    @BeforeEach
    void setUp() {
        applicationUserDao = mock(ApplicationUserDao.class);
        authUserDao = mock(AuthUserDao.class);
        roleDao = mock(RoleDao.class);

        service = new AdminUserService();
        ReflectionTestUtils.setField(service, "applicationUserDao", applicationUserDao);
        ReflectionTestUtils.setField(service, "authUserDao", authUserDao);
        ReflectionTestUtils.setField(service, "roleDao", roleDao);
        ReflectionTestUtils.setField(service, "refreshTokenDao", mock(RefreshTokenDao.class));
        ReflectionTestUtils.setField(service, "authService", mock(AuthService.class));

        when(roleDao.findById(1L)).thenReturn(superAdminRole);
        when(roleDao.findById(2L)).thenReturn(adminRole);
        when(roleDao.findById(10L)).thenReturn(userRole);
        when(applicationUserDao.update(any(ApplicationUser.class))).thenAnswer(inv -> inv.getArgument(0));
    }

    @AfterEach
    void clearSecurityContext() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void adminCannotChangeAUsersRole() {
        ApplicationUser target = existingUser(userRole);
        callerHasRole("ADMIN");

        assertThatThrownBy(() -> service.updateAppUser(TARGET_ID, profileUpdate(superAdminRole.getId())))
                .isInstanceOf(NotAllowedCustomException.class)
                .hasMessageContaining("Only a super admin can change a user's role");

        assertThat(roleNames(target)).containsExactly("USER");
        verify(applicationUserDao, never()).update(any());
    }

    @Test
    void adminMayResendTheCurrentRoleWhenEditingAProfile() {
        ApplicationUser target = existingUser(userRole);
        callerHasRole("ADMIN");

        AdminAppUserResponseDto result = service.updateAppUser(TARGET_ID, profileUpdate(userRole.getId()));

        assertThat(result.getFullName()).isEqualTo("Updated Name");
        assertThat(roleNames(target)).containsExactly("USER");
    }

    @Test
    void adminMayEditAProfileWithoutARole() {
        existingUser(userRole);
        callerHasRole("ADMIN");

        AdminAppUserResponseDto result = service.updateAppUser(TARGET_ID, profileUpdate(null));

        assertThat(result.getFullName()).isEqualTo("Updated Name");
    }

    @Test
    void superAdminCanChangeAUsersRole() {
        ApplicationUser target = existingUser(userRole);
        callerHasRole("SUPER_ADMIN");

        service.updateAppUser(TARGET_ID, profileUpdate(adminRole.getId()));

        assertThat(roleNames(target)).containsExactly("ADMIN");
    }

    @Test
    void adminCannotEditASuperAdminAccount() {
        existingUser(superAdminRole);
        callerHasRole("ADMIN");

        assertThatThrownBy(() -> service.updateAppUser(TARGET_ID, profileUpdate(null)))
                .isInstanceOf(NotAllowedCustomException.class)
                .hasMessageContaining("super admin account");
        verify(applicationUserDao, never()).update(any());
    }

    @Test
    void adminCannotDeleteASuperAdminAccount() {
        existingUser(superAdminRole);
        callerHasRole("ADMIN");

        assertThatThrownBy(() -> service.deleteUserProfile(TARGET_ID))
                .isInstanceOf(NotAllowedCustomException.class);
        assertThatThrownBy(() -> service.deleteAccount(TARGET_ID))
                .isInstanceOf(NotAllowedCustomException.class);

        verify(applicationUserDao, never()).delete(any());
        verify(authUserDao, never()).delete(any());
    }

    @Test
    void adminCanStillDeleteARegularUser() {
        ApplicationUser target = existingUser(userRole);
        callerHasRole("ADMIN");

        service.deleteAccount(TARGET_ID);

        verify(applicationUserDao).delete(target);
        verify(authUserDao).delete(target.getAuthUser());
    }

    @Test
    void editingAPhoneOnlyCustomerWithoutEmailKeepsTheirNumberAndLogin() {
        ApplicationUser target = existingUser(userRole);
        target.setEmail(null);
        target.setPhoneNumber("+919876543210");
        target.getAuthUser().setUsername("+919876543210");
        callerHasRole("ADMIN");
        UserProfileRequestDto update = profileUpdate(null);
        update.setEmail(null);

        AdminAppUserResponseDto result = service.updateAppUser(TARGET_ID, update);

        assertThat(result.getFullName()).isEqualTo("Updated Name");
        assertThat(target.getEmail()).isNull();
        assertThat(target.getPhoneNumber()).as("SMS still has a number to go to").isEqualTo("+919876543210");
        assertThat(target.getAuthUser().getUsername()).isEqualTo("+919876543210");
    }

    @Test
    void adminCanAddAnEmailToAPhoneOnlyCustomer() {
        ApplicationUser target = existingUser(userRole);
        target.setEmail(null);
        target.getAuthUser().setUsername("+919876543210");
        callerHasRole("ADMIN");
        UserProfileRequestDto update = profileUpdate(null);
        update.setEmail(" New@Example.com ");

        service.updateAppUser(TARGET_ID, update);

        assertThat(target.getEmail()).isEqualTo("new@example.com");
        assertThat(target.getAuthUser().getUsername()).isEqualTo("new@example.com");
    }

    private ApplicationUser existingUser(Role currentRole) {
        AuthUser authUser = new AuthUser();
        authUser.setId(43L);
        authUser.setUsername("target@example.com");
        authUser.addRole(currentRole);

        ApplicationUser appUser = new ApplicationUser();
        appUser.setId(TARGET_ID);
        appUser.setEmail("target@example.com");
        appUser.setFullName("Original Name");
        appUser.setAuthUser(authUser);

        when(applicationUserDao.findById(TARGET_ID)).thenReturn(appUser);
        return appUser;
    }

    private static UserProfileRequestDto profileUpdate(Long roleId) {
        UserProfileRequestDto dto = new UserProfileRequestDto();
        dto.setEmail("target@example.com");
        dto.setFullName("Updated Name");
        dto.setRoleId(roleId);
        return dto;
    }

    private static void callerHasRole(String role) {
        SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(
                "caller", null, List.of(new SimpleGrantedAuthority("ROLE_" + role))));
    }

    private static List<String> roleNames(ApplicationUser appUser) {
        return appUser.getAuthUser().getUserRoles().stream()
                .map(AuthUserRole::getRole).map(Role::getName).toList();
    }

    private static Role role(Long id, String name) {
        Role role = new Role(name, name);
        role.setId(id);
        return role;
    }
}
