package com.forvmom.core.config;

import org.junit.jupiter.api.Test;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** application_users.email becomes optional on existing PostgreSQL databases. */
class SchemaPatchRunnerTest {

    @Test
    void postgresGetsThePatchCommitted() throws Exception {
        Fixture db = new Fixture("PostgreSQL");

        new SchemaPatchRunner(db.dataSource, true).run(null);

        verify(db.statement).execute("ALTER TABLE IF EXISTS application_users ALTER COLUMN email DROP NOT NULL");
        verify(db.connection).commit(); // pool has auto-commit off
    }

    @Test
    void otherDatabasesAndSwitchedOffAreLeftAlone() throws Exception {
        Fixture h2 = new Fixture("H2");
        new SchemaPatchRunner(h2.dataSource, true).run(null);
        verify(h2.statement, never()).execute(anyString());

        Fixture off = new Fixture("PostgreSQL");
        new SchemaPatchRunner(off.dataSource, false).run(null);
        verify(off.dataSource, never()).getConnection();
    }

    @Test
    void aFailedPatchDoesNotStopStartUp() throws Exception {
        Fixture db = new Fixture("PostgreSQL");
        when(db.statement.execute(anyString())).thenThrow(new SQLException("permission denied"));

        assertThatCode(() -> new SchemaPatchRunner(db.dataSource, true).run(null)).doesNotThrowAnyException();
    }

    private static final class Fixture {
        final DataSource dataSource = mock(DataSource.class);
        final Connection connection = mock(Connection.class);
        final Statement statement = mock(Statement.class);

        Fixture(String product) throws SQLException {
            DatabaseMetaData meta = mock(DatabaseMetaData.class);
            when(dataSource.getConnection()).thenReturn(connection);
            when(connection.getMetaData()).thenReturn(meta);
            when(meta.getDatabaseProductName()).thenReturn(product);
            when(connection.createStatement()).thenReturn(statement);
            when(connection.getAutoCommit()).thenReturn(false);
        }
    }
}
