package com.forvmom.core.services;

import com.forvmom.common.dto.request.ExperienceCloneRequestDto;
import com.forvmom.common.dto.response.ExperienceCloneResponseDto;
import com.forvmom.common.errorhandler.ConflictException;
import com.forvmom.common.errorhandler.ResourceNotFoundException;
import com.forvmom.data.dao.ExperienceDao;
import com.forvmom.data.dao.SubCategoryDao;
import com.forvmom.data.entities.Addon;
import com.forvmom.data.entities.Coupon;
import com.forvmom.data.entities.Experience;
import com.forvmom.data.entities.ExperienceAddonMapper;
import com.forvmom.data.entities.ExperienceCancellationPolicy;
import com.forvmom.data.entities.ExperienceCancellationPolicyMapper;
import com.forvmom.data.entities.ExperienceCouponMapper;
import com.forvmom.data.entities.ExperienceDetail;
import com.forvmom.data.entities.ExperienceInclusion;
import com.forvmom.data.entities.ExperienceInclusionMapper;
import com.forvmom.data.entities.ExperienceLocationMapper;
import com.forvmom.data.entities.ExperienceLocationPincodeMapper;
import com.forvmom.data.entities.ExperienceMediaMapper;
import com.forvmom.data.entities.ExperienceTimeSlotMapper;
import com.forvmom.data.entities.Location;
import com.forvmom.data.entities.Media;
import com.forvmom.data.entities.Pincode;
import com.forvmom.data.entities.SubCategory;
import com.forvmom.data.entities.TimeSlot;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * Unit tests for {@link ExperienceCloneService}. The source experience graph is
 * built in memory and handed back by the mocked DAO, so each test checks
 * exactly what the copy would persist.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ExperienceCloneServiceTest {

    private static final Long SOURCE_ID = 10L;

    @Mock
    private ExperienceDao experienceDao;
    @Mock
    private SubCategoryDao subCategoryDao;
    @Mock
    private CatalogCacheService catalogCacheService;
    @Mock
    private ImageFlowCacheService imageFlowCacheService;

    private ExperienceCloneService service;

    private SubCategory subCategory;
    private ExperienceInclusion inclusion1;
    private ExperienceInclusion inclusion2;
    private ExperienceCancellationPolicy policy;
    private Addon addon;
    private Coupon coupon;
    private Media heroImage;
    private Media secondImage;
    private Location bengaluru;
    private Location mumbai;
    private Pincode pincode560001;
    private Pincode pincode560002;
    private TimeSlot evening;
    private TimeSlot night;

    @BeforeEach
    void setUp() {
        service = new ExperienceCloneService(experienceDao, subCategoryDao, catalogCacheService, imageFlowCacheService);
        when(experienceDao.existsBySlugIncludingDeleted(anyString())).thenReturn(false);
        when(experienceDao.save(any(Experience.class))).thenAnswer(invocation -> invocation.getArgument(0));
    }

    @Test
    void copiesEveryPartOfTheExperienceWithDefaults() {
        Experience source = fullSource();
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(source);

        ExperienceCloneResponseDto response = service.cloneExperience(SOURCE_ID, null);
        Experience copy = savedCopy();

        // Experience row
        assertNotSame(source, copy);
        assertNull(copy.getId());
        assertEquals("Rooftop Dinner (Copy)", copy.getName());
        assertEquals("rooftop-dinner-copy", copy.getSlug());
        assertEquals("romantic", copy.getTagName());
        assertEquals(new BigDecimal("4999.00"), copy.getBasePrice());
        assertEquals(7, copy.getDisplayOrder());
        assertSame(subCategory, copy.getSubCategory());
        assertFalse(copy.isActive(), "copy must start hidden");
        assertFalse(copy.getIsFeatured(), "copy must not be featured");

        // Detail row
        ExperienceDetail detail = copy.getDetail();
        assertNotSame(source.getDetail(), detail);
        assertNull(detail.getId());
        assertSame(copy, detail.getExperience());
        assertEquals("Short", detail.getShortDescription());
        assertEquals("Long description", detail.getDescription());
        assertEquals(120, detail.getDurationMinutes());
        assertEquals(2, detail.getMaxCapacity());
        assertEquals(18, detail.getMinAge());
        assertEquals(45, detail.getCompletionTime());
        assertEquals(6, detail.getMinHours());
        assertEquals("Terms", detail.getTermsConditions());
        assertEquals("ID card", detail.getWhatToBring());
        assertTrue(detail.getIsActive());

        // Inclusions and policies: new link rows to the same masters, same order
        List<ExperienceInclusionMapper> inclusions = sorted(copy.getInclusionMappers(),
                m -> m.getInclusion().getId());
        assertEquals(2, inclusions.size());
        assertSame(inclusion1, inclusions.get(0).getInclusion());
        assertEquals(1, inclusions.get(0).getDisplayOrder());
        assertSame(inclusion2, inclusions.get(1).getInclusion());
        assertEquals(2, inclusions.get(1).getDisplayOrder());
        assertFalse(inclusions.get(1).getIsActive());
        inclusions.forEach(m -> {
            assertNull(m.getId());
            assertSame(copy, m.getExperience());
        });

        ExperienceCancellationPolicyMapper policyLink = copy.getPolicyMappers().iterator().next();
        assertEquals(1, copy.getPolicyMappers().size());
        assertSame(policy, policyLink.getPolicy());
        assertEquals(3, policyLink.getDisplayOrder());
        assertSame(copy, policyLink.getExperience());

        // Add-ons keep their per-experience price and free flag
        ExperienceAddonMapper addonLink = copy.getAddonMappers().iterator().next();
        assertEquals(1, copy.getAddonMappers().size(), "deleted add-on link must be skipped");
        assertSame(addon, addonLink.getAddon());
        assertEquals(new BigDecimal("299.00"), addonLink.getPriceOverride());
        assertTrue(addonLink.getIsFree());
        assertSame(copy, addonLink.getExperience());

        // Coupons
        ExperienceCouponMapper couponLink = copy.getCouponMappers().iterator().next();
        assertEquals(1, copy.getCouponMappers().size());
        assertSame(coupon, couponLink.getCoupon());
        assertSame(copy, couponLink.getExperience());

        // Gallery shares the image records; primary flag and alt text are kept
        List<ExperienceMediaMapper> media = sorted(copy.getMediaMappers(), m -> m.getMedia().getId());
        assertEquals(2, media.size());
        assertSame(heroImage, media.get(0).getMedia());
        assertTrue(media.get(0).getIsPrimary());
        assertEquals("Hero alt", media.get(0).getAltText());
        assertEquals(0, media.get(0).getDisplayOrder());
        assertSame(secondImage, media.get(1).getMedia());
        assertFalse(media.get(1).getIsPrimary());
        assertEquals(1, media.get(1).getDisplayOrder());

        // Cities, with their pincode rule and time slots
        List<ExperienceLocationMapper> cities = sorted(copy.getLocationMappers(), m -> m.getLocation().getId());
        assertEquals(2, cities.size());

        ExperienceLocationMapper blr = cities.get(0);
        assertSame(bengaluru, blr.getLocation());
        assertSame(copy, blr.getExperience());
        assertNull(blr.getId());
        assertEquals(new BigDecimal("5499.00"), blr.getPriceOverride());
        assertTrue(blr.getIsActive());
        assertEquals(LocalDate.of(2026, 1, 1), blr.getValidFrom());
        assertEquals(LocalDate.of(2026, 12, 31), blr.getValidTo());
        assertEquals("BLACKLIST", blr.getPincodeRestrictionType());

        List<ExperienceLocationPincodeMapper> pincodes = sorted(blr.getPincodeMappers(),
                m -> m.getPincode().getId());
        assertEquals(2, pincodes.size());
        assertSame(pincode560001, pincodes.get(0).getPincode());
        assertSame(pincode560002, pincodes.get(1).getPincode());
        pincodes.forEach(p -> assertSame(blr, p.getExperienceLocationMapper()));

        List<ExperienceTimeSlotMapper> blrSlots = sorted(blr.getTimeSlotMappers(), m -> m.getTimeSlot().getId());
        assertEquals(2, blrSlots.size(), "deleted slot link must be skipped");
        ExperienceTimeSlotMapper eveningSlot = blrSlots.get(0);
        assertSame(evening, eveningSlot.getTimeSlot());
        assertSame(blr, eveningSlot.getExperienceLocation());
        assertNull(eveningSlot.getId());
        assertEquals(new BigDecimal("5999.00"), eveningSlot.getPriceOverride());
        assertEquals(8, eveningSlot.getMaxCapacity());
        assertTrue(eveningSlot.getIsActive());
        assertEquals(LocalDate.of(2026, 2, 1), eveningSlot.getValidFrom());
        assertEquals(LocalDate.of(2026, 11, 30), eveningSlot.getValidTo());
        assertSame(night, blrSlots.get(1).getTimeSlot());
        assertFalse(blrSlots.get(1).getIsActive());

        ExperienceLocationMapper bom = cities.get(1);
        assertSame(mumbai, bom.getLocation());
        assertFalse(bom.getIsActive());
        assertEquals("WHITELIST", bom.getPincodeRestrictionType());
        assertTrue(bom.getPincodeMappers().isEmpty());
        assertEquals(1, bom.getTimeSlotMappers().size());

        // Response
        assertEquals(SOURCE_ID, response.getSourceExperienceId());
        assertEquals("rooftop-dinner-copy", response.getExperience().getSlug());
        assertEquals(Boolean.FALSE, response.getExperience().getIsActive());
        assertEquals("Long description", response.getExperience().getDetail().getDescription());
        ExperienceCloneResponseDto.CopiedParts copied = response.getCopied();
        assertTrue(copied.isDetail());
        assertEquals(2, copied.getInclusions());
        assertEquals(1, copied.getCancellationPolicies());
        assertEquals(1, copied.getAddons());
        assertEquals(1, copied.getCoupons());
        assertEquals(2, copied.getMedia());
        assertEquals(2, copied.getLocations());
        assertEquals(2, copied.getPincodes());
        assertEquals(3, copied.getTimeSlots());
    }

    @Test
    void leavesTheSourceExperienceUntouched() {
        Experience source = fullSource();
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(source);

        service.cloneExperience(SOURCE_ID, null);

        assertEquals(SOURCE_ID, source.getId());
        assertEquals("rooftop-dinner", source.getSlug());
        assertEquals(2, source.getInclusionMappers().size());
        assertEquals(2, source.getAddonMappers().size());
        assertEquals(2, source.getLocationMappers().size());
        source.getLocationMappers().forEach(m -> assertSame(source, m.getExperience()));
        source.getMediaMappers().forEach(m -> assertSame(source, m.getExperience()));
        assertSame(source, source.getDetail().getExperience());
    }

    @Test
    void appliesTheRequestedNameSlugSubCategoryAndVisibility() {
        Experience source = fullSource();
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(source);
        SubCategory other = new SubCategory();
        other.setId(99L);
        when(subCategoryDao.findById(99L)).thenReturn(other);

        ExperienceCloneRequestDto request = new ExperienceCloneRequestDto();
        request.setName("  Poolside Dinner  ");
        request.setSlug(" poolside-dinner ");
        request.setSubCategoryId(99L);
        request.setIsActive(true);
        request.setIsFeatured(true);

        service.cloneExperience(SOURCE_ID, request);
        Experience copy = savedCopy();

        assertEquals("Poolside Dinner", copy.getName());
        assertEquals("poolside-dinner", copy.getSlug());
        assertSame(other, copy.getSubCategory());
        assertTrue(copy.isActive());
        assertTrue(copy.getIsFeatured());
    }

    @Test
    void picksTheNextFreeCopySlug() {
        Experience source = fullSource();
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(source);
        when(experienceDao.existsBySlugIncludingDeleted("rooftop-dinner-copy")).thenReturn(true);
        when(experienceDao.existsBySlugIncludingDeleted("rooftop-dinner-copy-2")).thenReturn(true);

        service.cloneExperience(SOURCE_ID, null);

        assertEquals("rooftop-dinner-copy-3", savedCopy().getSlug());
    }

    @Test
    void cloningACopyDoesNotStackSuffixes() {
        Experience source = fullSource();
        source.setName("Rooftop Dinner (Copy)");
        source.setSlug("rooftop-dinner-copy");
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(source);
        when(experienceDao.existsBySlugIncludingDeleted("rooftop-dinner-copy")).thenReturn(true);

        service.cloneExperience(SOURCE_ID, null);
        Experience copy = savedCopy();

        assertEquals("Rooftop Dinner (Copy)", copy.getName());
        assertEquals("rooftop-dinner-copy-2", copy.getSlug());
    }

    @Test
    void keepsLongSlugsWithinTheColumnLength() {
        Experience source = fullSource();
        source.setSlug("a".repeat(220));
        source.setName("n".repeat(255));
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(source);

        service.cloneExperience(SOURCE_ID, null);
        Experience copy = savedCopy();

        assertTrue(copy.getSlug().length() <= 220, "slug length " + copy.getSlug().length());
        assertTrue(copy.getSlug().endsWith("-copy"));
        assertTrue(copy.getName().length() <= 255, "name length " + copy.getName().length());
        assertTrue(copy.getName().endsWith(" (Copy)"));
    }

    @Test
    void rejectsARequestedSlugThatIsAlreadyUsedEvenBySoftDeletedRows() {
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(fullSource());
        when(experienceDao.existsBySlugIncludingDeleted("taken")).thenReturn(true);
        ExperienceCloneRequestDto request = new ExperienceCloneRequestDto();
        request.setSlug("taken");

        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> service.cloneExperience(SOURCE_ID, request));

        assertTrue(error.getMessage().contains("taken"));
        verify(experienceDao, never()).save(any());
    }

    @Test
    void failsWithConflictWhenNoCopySlugIsFree() {
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(fullSource());
        when(experienceDao.existsBySlugIncludingDeleted(anyString())).thenReturn(true);

        assertThrows(ConflictException.class, () -> service.cloneExperience(SOURCE_ID, null));
        verify(experienceDao, never()).save(any());
    }

    @Test
    void failsWhenTheSourceDoesNotExist() {
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(null);

        assertThrows(ResourceNotFoundException.class, () -> service.cloneExperience(SOURCE_ID, null));
        verify(experienceDao, never()).save(any());
    }

    @Test
    void failsWhenTheRequestedSubCategoryDoesNotExist() {
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(fullSource());
        when(subCategoryDao.findById(404L)).thenReturn(null);
        ExperienceCloneRequestDto request = new ExperienceCloneRequestDto();
        request.setSubCategoryId(404L);

        assertThrows(ResourceNotFoundException.class, () -> service.cloneExperience(SOURCE_ID, request));
        verify(experienceDao, never()).save(any());
    }

    @Test
    void copiesAnExperienceThatHasNothingAttached() {
        Experience source = bareSource();
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(source);

        ExperienceCloneResponseDto response = service.cloneExperience(SOURCE_ID, null);
        Experience copy = savedCopy();

        assertNull(copy.getDetail());
        assertTrue(copy.getLocationMappers().isEmpty());
        assertFalse(response.getCopied().isDetail());
        assertEquals(0, response.getCopied().getLocations());
    }

    @Test
    void warmsTheBookingCacheForTheCopy() {
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(fullSource());

        service.cloneExperience(SOURCE_ID, null);
        Experience copy = savedCopy();

        verify(imageFlowCacheService).evictExperienceLists();
        verify(catalogCacheService).warmExperienceCache(copy);
        copy.getLocationMappers().forEach(m -> verify(catalogCacheService).warmLocationCache(m));
        copy.getLocationMappers().forEach(m -> m.getTimeSlotMappers()
                .forEach(s -> verify(catalogCacheService).warmSlotCache(s)));
        copy.getAddonMappers().forEach(a -> verify(catalogCacheService).warmAddonCache(a));
    }

    @Test
    void aRedisFailureDoesNotUndoTheCopy() {
        when(experienceDao.findByIdWithDetail(SOURCE_ID)).thenReturn(fullSource());
        doThrow(new IllegalStateException("redis down")).when(imageFlowCacheService).evictExperienceLists();
        doThrow(new IllegalStateException("redis down")).when(catalogCacheService)
                .warmExperienceCache(any(Experience.class));

        ExperienceCloneResponseDto response = service.cloneExperience(SOURCE_ID, null);

        assertEquals("rooftop-dinner-copy", response.getExperience().getSlug());
        verify(experienceDao).save(any(Experience.class));
    }

    // ── Fixtures ──────────────────────────────────────────────────────────────

    private Experience savedCopy() {
        ArgumentCaptor<Experience> captor = ArgumentCaptor.forClass(Experience.class);
        verify(experienceDao).save(captor.capture());
        return captor.getValue();
    }

    private static <T> List<T> sorted(java.util.Collection<T> rows, Function<T, Long> key) {
        return rows.stream().sorted(Comparator.comparing(key)).toList();
    }

    private Experience bareSource() {
        subCategory = new SubCategory();
        subCategory.setId(21L);
        subCategory.setName("Candlelight Dinners");

        Experience source = new Experience();
        source.setId(SOURCE_ID);
        source.setName("Rooftop Dinner");
        source.setSlug("rooftop-dinner");
        source.setTagName("romantic");
        source.setBasePrice(new BigDecimal("4999.00"));
        source.setDisplayOrder(7);
        source.setIsFeatured(true);
        source.setActive(true);
        source.setSubCategory(subCategory);
        return source;
    }

    private Experience fullSource() {
        Experience source = bareSource();

        ExperienceDetail detail = new ExperienceDetail();
        detail.setId(500L);
        detail.setShortDescription("Short");
        detail.setDescription("Long description");
        detail.setDurationMinutes(120);
        detail.setMaxCapacity(2);
        detail.setMinAge(18);
        detail.setCompletionTime(45);
        detail.setMinHours(6);
        detail.setTermsConditions("Terms");
        detail.setWhatToBring("ID card");
        detail.setIsActive(true);
        source.setDetail(detail);

        inclusion1 = new ExperienceInclusion();
        inclusion1.setId(31L);
        inclusion2 = new ExperienceInclusion();
        inclusion2.setId(32L);
        source.addInclusionMapper(inclusionLink(101L, inclusion1, 1, true));
        source.addInclusionMapper(inclusionLink(102L, inclusion2, 2, false));

        policy = new ExperienceCancellationPolicy();
        policy.setId(41L);
        ExperienceCancellationPolicyMapper policyLink = new ExperienceCancellationPolicyMapper();
        policyLink.setId(201L);
        policyLink.setPolicy(policy);
        policyLink.setDisplayOrder(3);
        policyLink.setIsActive(true);
        source.addPolicyMapper(policyLink);

        addon = new Addon();
        addon.setId(51L);
        ExperienceAddonMapper addonLink = new ExperienceAddonMapper();
        addonLink.setId(301L);
        addonLink.setAddon(addon);
        addonLink.setPriceOverride(new BigDecimal("299.00"));
        addonLink.setIsFree(true);
        addonLink.setIsActive(true);
        source.addAddonMapper(addonLink);
        ExperienceAddonMapper deletedAddonLink = new ExperienceAddonMapper();
        deletedAddonLink.setId(302L);
        deletedAddonLink.setAddon(new Addon());
        deletedAddonLink.setDeleted(true);
        source.addAddonMapper(deletedAddonLink);

        coupon = new Coupon();
        coupon.setId(61L);
        ExperienceCouponMapper couponLink = new ExperienceCouponMapper();
        couponLink.setId(401L);
        couponLink.setCoupon(coupon);
        couponLink.setIsActive(true);
        source.addCouponMapper(couponLink);

        heroImage = new Media();
        heroImage.setId(71L);
        secondImage = new Media();
        secondImage.setId(72L);
        source.addMediaMapper(mediaLink(501L, heroImage, 0, true, "Hero alt"));
        source.addMediaMapper(mediaLink(502L, secondImage, 1, false, null));

        bengaluru = new Location();
        bengaluru.setId(1L);
        mumbai = new Location();
        mumbai.setId(2L);
        pincode560001 = new Pincode();
        pincode560001.setId(81L);
        pincode560002 = new Pincode();
        pincode560002.setId(82L);
        evening = new TimeSlot();
        evening.setId(91L);
        evening.setLabel("Evening");
        evening.setStartTime(LocalTime.of(19, 0));
        night = new TimeSlot();
        night.setId(92L);

        ExperienceLocationMapper blr = new ExperienceLocationMapper();
        blr.setId(601L);
        blr.setLocation(bengaluru);
        blr.setPriceOverride(new BigDecimal("5499.00"));
        blr.setIsActive(true);
        blr.setValidFrom(LocalDate.of(2026, 1, 1));
        blr.setValidTo(LocalDate.of(2026, 12, 31));
        blr.setPincodeRestrictionType("BLACKLIST");
        blr.addPincodeMapper(pincodeLink(701L, pincode560001));
        blr.addPincodeMapper(pincodeLink(702L, pincode560002));
        blr.addTimeSlotMapper(slotLink(801L, evening, new BigDecimal("5999.00"), 8, true,
                LocalDate.of(2026, 2, 1), LocalDate.of(2026, 11, 30)));
        blr.addTimeSlotMapper(slotLink(802L, night, null, 20, false, null, null));
        ExperienceTimeSlotMapper deletedSlot = slotLink(803L, new TimeSlot(), null, 5, true, null, null);
        deletedSlot.setDeleted(true);
        blr.addTimeSlotMapper(deletedSlot);
        source.addLocationMapper(blr);

        ExperienceLocationMapper bom = new ExperienceLocationMapper();
        bom.setId(602L);
        bom.setLocation(mumbai);
        bom.setIsActive(false);
        bom.addTimeSlotMapper(slotLink(804L, evening, null, 10, true, null, null));
        source.addLocationMapper(bom);

        return source;
    }

    private static ExperienceInclusionMapper inclusionLink(Long id, ExperienceInclusion inclusion,
            int order, boolean active) {
        ExperienceInclusionMapper link = new ExperienceInclusionMapper();
        link.setId(id);
        link.setInclusion(inclusion);
        link.setDisplayOrder(order);
        link.setIsActive(active);
        return link;
    }

    private static ExperienceMediaMapper mediaLink(Long id, Media media, int order, boolean primary,
            String altText) {
        ExperienceMediaMapper link = new ExperienceMediaMapper();
        link.setId(id);
        link.setMedia(media);
        link.setDisplayOrder(order);
        link.setIsPrimary(primary);
        link.setAltText(altText);
        link.setIsActive(true);
        return link;
    }

    private static ExperienceLocationPincodeMapper pincodeLink(Long id, Pincode pincode) {
        ExperienceLocationPincodeMapper link = new ExperienceLocationPincodeMapper();
        link.setId(id);
        link.setPincode(pincode);
        link.setIsActive(true);
        return link;
    }

    private static ExperienceTimeSlotMapper slotLink(Long id, TimeSlot slot, BigDecimal price, int capacity,
            boolean active, LocalDate from, LocalDate to) {
        ExperienceTimeSlotMapper link = new ExperienceTimeSlotMapper();
        link.setId(id);
        link.setTimeSlot(slot);
        link.setPriceOverride(price);
        link.setMaxCapacity(capacity);
        link.setIsActive(active);
        link.setValidFrom(from);
        link.setValidTo(to);
        return link;
    }
}
