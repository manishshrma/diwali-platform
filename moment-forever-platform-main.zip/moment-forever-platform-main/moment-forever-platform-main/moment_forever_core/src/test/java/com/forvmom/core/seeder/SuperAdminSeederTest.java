package com.forvmom.core.seeder;

import com.forvmom.data.dao.auth.AuthUserDao;
import com.forvmom.data.dao.auth.RoleDao;
import com.forvmom.data.entities.auth.Role;
import com.forvmom.security.dto.RegisterRequestDto;
import com.forvmom.security.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * S1: the first super admin comes only from configuration; there is no
 * built-in password.
 */
class SuperAdminSeederTest {

    private AuthService authService;
    private RoleDao roleDao;
    private AuthUserDao authUserDao;

    @BeforeEach
    void setUp() {
        authService = mock(AuthService.class);
        roleDao = mock(RoleDao.class);
        authUserDao = mock(AuthUserDao.class);

        Role superAdmin = new Role("SUPER_ADMIN", "Super Administrator");
        superAdmin.setId(1L);
        when(roleDao.findByNameIgnoreCase("SUPER_ADMIN")).thenReturn(Optional.of(superAdmin));
    }

    @Test
    void createsSuperAdminFromConfiguredCredentials() {
        seeder(" Owner@Example.com ", "a-long-password").run();

        ArgumentCaptor<RegisterRequestDto> request = ArgumentCaptor.forClass(RegisterRequestDto.class);
        verify(authService).createAccount(request.capture());
        assertThat(request.getValue().getEmail()).isEqualTo("owner@example.com");
        assertThat(request.getValue().getPassword()).isEqualTo("a-long-password");
        assertThat(request.getValue().getRoleId()).isEqualTo(1L);
    }

    @Test
    void doesNothingWithoutAPassword() {
        seeder("owner@example.com", "").run();

        verify(authService, never()).createAccount(any());
    }

    @Test
    void doesNothingWithAShortPassword() {
        seeder("owner@example.com", "test123").run();

        verify(authService, never()).createAccount(any());
    }

    @Test
    void doesNothingWithoutAnEmail() {
        seeder("", "a-long-password").run();

        verify(authService, never()).createAccount(any());
    }

    @Test
    void neverTouchesAnExistingAccount() {
        when(authUserDao.existsByUsername("owner@example.com")).thenReturn(true);

        seeder("owner@example.com", "a-long-password").run();

        verify(authService, never()).createAccount(any());
    }

    private SuperAdminSeeder seeder(String email, String password) {
        return new SuperAdminSeeder(authService, roleDao, authUserDao, email, password);
    }
}
