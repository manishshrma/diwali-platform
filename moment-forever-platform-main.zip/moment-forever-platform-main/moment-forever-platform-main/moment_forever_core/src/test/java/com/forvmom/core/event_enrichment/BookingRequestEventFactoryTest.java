package com.forvmom.core.event_enrichment;

import com.forvmom.common.dto.events.BookingRequestEvent;
import com.forvmom.common.helpers.BookingOutboxPayload;
import com.forvmom.common.helpers.BookingPricingSummary;
import com.forvmom.common.helpers.BookingSnapshotBundle;
import com.forvmom.data.entities.BookingOutbox;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.mock;

class BookingRequestEventFactoryTest {

    @Test
    void retryRebuildsEventWithPersistedIdentity() {
        BookingOutbox outbox = new BookingOutbox();
        outbox.setBookingReferenceId("MFB-100");
        outbox.setEventId("evt-stable-1");
        outbox.setEventProducer("moment-forever-core");
        outbox.setSchemaVersion(1);
        outbox.setOccurredAt(Instant.parse("2026-08-20T10:00:00Z"));
        outbox.setCorrelationId("corr-1");

        BookingOutboxPayload payload = mock(BookingOutboxPayload.class);
        BookingSnapshotBundle snapshots =
                mock(BookingSnapshotBundle.class, RETURNS_DEEP_STUBS);
        BookingPricingSummary pricing = mock(BookingPricingSummary.class);
        BookingRequestEventFactory factory = new BookingRequestEventFactory();

        BookingRequestEvent first = factory.create(outbox, payload, snapshots, pricing);
        BookingRequestEvent retry = factory.create(outbox, payload, snapshots, pricing);

        assertEquals(first.getEventId(), retry.getEventId());
        assertEquals("evt-stable-1", retry.getEventId());
        assertEquals(first.getOccurredAt(), retry.getOccurredAt());
        assertEquals("MFB-100", retry.getBookingId());
    }

    @Test
    void customerPhoneIsCarriedForWhatsAppNotifications() {
        BookingOutbox outbox = new BookingOutbox();
        outbox.setBookingReferenceId("MFB-101");
        outbox.setEventId("evt-2");
        outbox.setEventProducer("moment-forever-core");
        outbox.setSchemaVersion(1);
        outbox.setOccurredAt(Instant.parse("2026-08-20T10:00:00Z"));
        outbox.setCorrelationId("corr-2");
        BookingSnapshotBundle snapshots = mock(BookingSnapshotBundle.class, RETURNS_DEEP_STUBS);
        org.mockito.Mockito.when(snapshots.getUserSnapshot().getPhoneNumber()).thenReturn("+919876543210");

        BookingRequestEvent event = new BookingRequestEventFactory().create(
                outbox, mock(BookingOutboxPayload.class), snapshots, mock(BookingPricingSummary.class));

        assertEquals("+919876543210", event.getUserPhone());
    }

    @Test
    void cachedUserSnapshotStoresTheProfilePhoneInE164() throws Exception {
        org.springframework.data.redis.core.StringRedisTemplate redis =
                mock(org.springframework.data.redis.core.StringRedisTemplate.class);
        @SuppressWarnings("unchecked")
        org.springframework.data.redis.core.ValueOperations<String, String> values =
                mock(org.springframework.data.redis.core.ValueOperations.class);
        org.mockito.Mockito.when(redis.opsForValue()).thenReturn(values);
        com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        com.forvmom.core.services.CatalogCacheService cache =
                new com.forvmom.core.services.CatalogCacheService(redis, mapper);
        com.forvmom.data.entities.ApplicationUser user = new com.forvmom.data.entities.ApplicationUser();
        user.setId(7L);
        user.setEmail("guest@example.com");
        user.setFullName("Guest");
        user.setPhoneNumber("98765 43210"); // typed without country code

        cache.warmUserCache(user);

        org.mockito.ArgumentCaptor<String> json = org.mockito.ArgumentCaptor.forClass(String.class);
        org.mockito.Mockito.verify(values).set(org.mockito.ArgumentMatchers.eq("user:7"), json.capture(),
                org.mockito.ArgumentMatchers.anyLong(), org.mockito.ArgumentMatchers.any());
        assertEquals("+919876543210", mapper.readTree(json.getValue()).get("phoneNumber").asText());
    }
}
