package com.forvmom.core.controller.admin;

import com.forvmom.common.dto.request.ExperienceCloneRequestDto;
import com.forvmom.common.dto.response.ExperienceCloneResponseDto;
import com.forvmom.common.dto.response.ExperienceResponseDto;
import com.forvmom.common.errorhandler.GlobalExceptionHandler;
import com.forvmom.common.errorhandler.ResourceNotFoundException;
import com.forvmom.core.services.ExperienceCloneService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * HTTP contract of {@code POST /admin/experiences/{id}/clone}: optional body,
 * 201 with the copy, validation and not-found mapping.
 */
class ExperienceControllerAdminCloneTest {

    private ExperienceCloneService cloneService;
    private MockMvc mockMvc;

    @BeforeEach
    void setUp() {
        cloneService = mock(ExperienceCloneService.class);
        ExperienceControllerAdmin controller = new ExperienceControllerAdmin();
        ReflectionTestUtils.setField(controller, "experienceCloneService", cloneService);
        mockMvc = MockMvcBuilders
                .standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler())
                .build();
    }

    @Test
    void clonesWithoutABody() throws Exception {
        when(cloneService.cloneExperience(eq(10L), isNull())).thenReturn(result(10L, 55L, "rooftop-dinner-copy"));

        mockMvc.perform(post("/admin/experiences/10/clone"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.code").value(201))
                .andExpect(jsonPath("$.response.sourceExperienceId").value(10))
                .andExpect(jsonPath("$.response.experience.id").value(55))
                .andExpect(jsonPath("$.response.experience.slug").value("rooftop-dinner-copy"))
                .andExpect(jsonPath("$.response.copied.locations").value(2))
                .andExpect(jsonPath("$.response.copied.timeSlots").value(3));

        verify(cloneService).cloneExperience(eq(10L), isNull());
    }

    @Test
    void passesTheRequestedSettingsToTheService() throws Exception {
        when(cloneService.cloneExperience(eq(10L), any())).thenReturn(result(10L, 56L, "poolside-dinner"));

        mockMvc.perform(post("/admin/experiences/10/clone")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "name": "Poolside Dinner",
                                  "slug": "poolside-dinner",
                                  "subCategoryId": 21,
                                  "isActive": true,
                                  "isFeatured": false
                                }
                                """))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.response.experience.slug").value("poolside-dinner"));

        ArgumentCaptor<ExperienceCloneRequestDto> captor = ArgumentCaptor.forClass(ExperienceCloneRequestDto.class);
        verify(cloneService).cloneExperience(eq(10L), captor.capture());
        ExperienceCloneRequestDto request = captor.getValue();
        assertEquals("Poolside Dinner", request.getName());
        assertEquals("poolside-dinner", request.getSlug());
        assertEquals(21L, request.getSubCategoryId());
        assertTrue(request.getIsActive());
        assertEquals(Boolean.FALSE, request.getIsFeatured());
    }

    @Test
    void rejectsASlugLongerThanTheColumn() throws Exception {
        mockMvc.perform(post("/admin/experiences/10/clone")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"slug\":\"" + "a".repeat(221) + "\"}"))
                .andExpect(status().isBadRequest());

        verify(cloneService, never()).cloneExperience(any(), any());
    }

    @Test
    void returnsNotFoundForAnUnknownExperience() throws Exception {
        when(cloneService.cloneExperience(eq(404L), any()))
                .thenThrow(new ResourceNotFoundException("Experience not found with id 404"));

        mockMvc.perform(post("/admin/experiences/404/clone"))
                .andExpect(status().isNotFound());
    }

    @Test
    void returnsBadRequestForATakenSlug() throws Exception {
        when(cloneService.cloneExperience(eq(10L), any()))
                .thenThrow(new IllegalArgumentException("Experience with slug 'taken' already exists"));

        mockMvc.perform(post("/admin/experiences/10/clone")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"slug\":\"taken\"}"))
                .andExpect(status().isBadRequest());
    }

    private static ExperienceCloneResponseDto result(Long sourceId, Long newId, String slug) {
        ExperienceResponseDto experience = new ExperienceResponseDto();
        experience.setId(newId);
        experience.setSlug(slug);
        experience.setIsActive(false);

        ExperienceCloneResponseDto response = new ExperienceCloneResponseDto();
        response.setSourceExperienceId(sourceId);
        response.setExperience(experience);
        response.getCopied().setLocations(2);
        response.getCopied().setTimeSlots(3);
        return response;
    }
}
