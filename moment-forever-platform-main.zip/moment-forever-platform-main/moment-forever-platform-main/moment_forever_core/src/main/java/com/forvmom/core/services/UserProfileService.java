package com.forvmom.core.services;

import com.forvmom.common.dto.response.AppUserResponseDto;
import com.forvmom.common.dto.request.UserProfileRequestDto;
import com.forvmom.common.errorhandler.ConflictException;
import com.forvmom.common.errorhandler.CustomAuthException;
import com.forvmom.common.errorhandler.ResourceNotFoundException;
import com.forvmom.core.mapper.ApplicationUserBeanMapper;
import com.forvmom.data.dao.ApplicationUserDao;
import com.forvmom.data.dao.auth.AuthUserDao;
import com.forvmom.data.dao.auth.RefreshTokenDao;
import com.forvmom.data.entities.ApplicationUser;
import com.forvmom.data.entities.auth.AuthUser;
import com.forvmom.data.entities.auth.RefreshToken;
import com.forvmom.security.config.PasswordConfig;
import com.forvmom.security.dto.JwtUserDetails;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Self-service profile operations for the currently authenticated user.
 *
 * <p>
 * Every method resolves the caller from the Spring Security context rather than
 * accepting a user id, so one user can never act on another's profile.
 *
 * <p>
 * Identity is split across two entities: {@code AuthUser} holds credentials while
 * {@link ApplicationUser} holds profile data. Anything touching the login
 * identifier must therefore update both, which is why the email change path below
 * writes to {@code AuthUser} as well.
 */
@Service
public class UserProfileService {

    private static final Logger logger = LoggerFactory.getLogger(UserProfileService.class);

    @Autowired
    private ApplicationUserDao applicationUserDao;

    @Autowired
    private AuthUserDao authUserDao;

    @Autowired
    private RefreshTokenDao refreshTokenDao;

    @Autowired
    private PasswordConfig passwordEncoder;

    private Long extractPrincipalUserId(Object o) {
        if (o instanceof JwtUserDetails) {
            return ((JwtUserDetails) o).getId();
        } else if (o instanceof UserDetails) {
            try {
                return Long.parseLong(((UserDetails) o).getUsername());
            } catch (NumberFormatException e) {
                return null;
            }
        } else if (o instanceof String) {
            try {
                return Long.parseLong((String) o);
            } catch (NumberFormatException e) {
                return null;
            }
        } else if (o instanceof Long) {
            return (Long) o;
        }
        return null;
    }

    private ApplicationUser resolveCurrentApplicationUser(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            throw new CustomAuthException("No authenticated user", HttpStatus.UNAUTHORIZED);
        }

        Object principal = authentication.getPrincipal();
        Long principalUserId = extractPrincipalUserId(principal);
        if (principalUserId == null) {
            throw new CustomAuthException("Invalid principal type", HttpStatus.UNAUTHORIZED);
        }

        ApplicationUser userByAppId = applicationUserDao.findById(principalUserId);
        if (userByAppId != null) {
            return userByAppId;
        }

        return applicationUserDao.findByAuthUserId(principalUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User doesn't exist in System"));
    }

    /**
     * Updates the authenticated user's profile.
     *
     * <p>
     * A changed email is also the login username, so it is propagated to the
     * {@code AuthUser} record and rejected if already taken. Both writes share this
     * transaction to avoid the profile and credentials disagreeing.
     *
     * @param userProfileRequestDto new profile values
     * @return the updated profile
     * @throws ResourceNotFoundException if the principal has no application user
     * @throws CustomAuthException       if the requested email is already in use
     */
    @Transactional
    public AppUserResponseDto updateCurrentUserProfile(@Valid UserProfileRequestDto userProfileRequestDto) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        ApplicationUser currentUser = resolveCurrentApplicationUser(authentication);
        String normalizedEmail = normalizeEmail(userProfileRequestDto.getEmail());

        // Update fields
        currentUser.setFullName(userProfileRequestDto.getFullName());

        // Sync email change with AuthUser. Email is optional (phone-only customers):
        // a blank value keeps the current email, a new one is added or replaces it.
        boolean emailGiven = normalizedEmail != null && !normalizedEmail.isBlank();
        if (emailGiven && !normalizedEmail.equalsIgnoreCase(currentUser.getEmail())) {
            Optional<ApplicationUser> existingUserWithEmail = applicationUserDao.findByEmailIgnoreCase(normalizedEmail);
            if (existingUserWithEmail.isPresent() && !existingUserWithEmail.get().getId().equals(currentUser.getId())) {
                throw new ConflictException("Email already in use: " + normalizedEmail);
            }
            AuthUser authUser = currentUser.getAuthUser();
            authUser.setUsername(normalizedEmail);
            authUserDao.save(authUser);
            currentUser.setEmail(normalizedEmail);
        }

        // Blank keeps the current number: for phone-only customers it is where
        // booking SMS go, so an edit form that omits it must not erase it.
        if (userProfileRequestDto.getPhoneNumber() != null && !userProfileRequestDto.getPhoneNumber().isBlank()) {
            currentUser.setPhoneNumber(userProfileRequestDto.getPhoneNumber());
        }
        currentUser.setProfilePictureUrl(userProfileRequestDto.getProfilePictureUrl());
        currentUser.setDateOfBirth(userProfileRequestDto.getDateOfBirth());
        currentUser.setPreferredCity(userProfileRequestDto.getPreferredCity());

        // Save updated user
        ApplicationUser updatedUser = applicationUserDao.update(currentUser);
        return ApplicationUserBeanMapper.mapEntityToDto(updatedUser);
    }

    /**
     * Returns the authenticated user's profile.
     *
     * @return the current user's profile
     * @throws CustomAuthException       if there is no authenticated principal or
     *                                   it is of an unexpected type
     * @throws ResourceNotFoundException if the principal has no application user
     */
    public AppUserResponseDto getCurrentUserProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        ApplicationUser applicationUser = resolveCurrentApplicationUser(authentication);
        return ApplicationUserBeanMapper.mapEntityToDto(applicationUser);
    }

    /**
     * Soft-deletes the authenticated user's profile and linked auth account.
     *
     * <p>
     * The password is re-verified first because a valid session alone is not
     * sufficient authorisation for an irreversible action. Refresh tokens are
     * revoked in the same transaction so deleted accounts cannot continue minting
     * new access tokens.
     *
     * @param password the caller's current password, for re-authentication
     * @throws CustomAuthException       if unauthenticated or the password is wrong
     * @throws ResourceNotFoundException if the principal has no application user
     */
    public void deleteCurrentUserProfile(String password) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        ApplicationUser applicationUser = resolveCurrentApplicationUser(authentication);

        // Verify password before deletion against AuthUser entity
        AuthUser authUser = applicationUser.getAuthUser();
        if (!passwordEncoder.passwordEncoder().matches(password, authUser.getPassword())) {
            throw new CustomAuthException("Invalid password", HttpStatus.UNAUTHORIZED);
        }
        revokeAllRefreshTokens(authUser.getId());
        applicationUserDao.delete(applicationUser);
        authUserDao.delete(authUser);
    }

    /**
     * Deactivates the authenticated user's account without deleting it.
     *
     * <p>
     * Locking the account alone would not end the session, because existing refresh
     * tokens could still mint new access tokens. All outstanding refresh tokens are
     * therefore revoked in the same transaction.
     *
     * @param refreshToken the caller's current refresh token (currently unused;
     *                     all of the user's tokens are revoked)
     * @throws CustomAuthException       if the principal is of an unexpected type
     * @throws ResourceNotFoundException if the principal has no application user
     */
    @Transactional
    public void deactivateCurrentAccount(String refreshToken) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        ApplicationUser applicationUser = resolveCurrentApplicationUser(authentication);
        AuthUser authUser = applicationUser.getAuthUser();
        authUser.setAccountNonLocked(false);
        authUserDao.update(authUser);

        // Revoke all refresh tokens for this user
        List<RefreshToken> tokens = refreshTokenDao
                .findByAuthUserIdAndRevokedFalse(authUser.getId());
        tokens.forEach(token -> {
            token.setRevoked(true);
            refreshTokenDao.save(token);
        });
        logger.info("User account deActivated successfully for userId: {}", authUser.getUsername());
    }

    private void revokeAllRefreshTokens(Long authUserId) {
        List<RefreshToken> tokens = refreshTokenDao.findByAuthUserIdAndRevokedFalse(authUserId);
        tokens.forEach(token -> {
            token.setRevoked(true);
            refreshTokenDao.save(token);
        });
    }

    private String normalizeEmail(String email) {
        return email == null ? null : email.trim().toLowerCase();
    }
}