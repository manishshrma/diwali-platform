package com.forvmom.core.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

/**
 * Small, idempotent schema changes that Hibernate's {@code ddl-auto: update}
 * cannot make on an existing table (it adds columns and tables, but never drops
 * a NOT NULL rule). PostgreSQL only; every statement is safe to run on every
 * start. The same SQL is in
 * {@code moment_forever_data/src/main/resources/sql/make_application_user_email_optional.sql}
 * for DBAs.
 *
 * <p>
 * Current patches:
 * <ul>
 * <li>{@code application_users.email} becomes optional, for customers who sign
 * up with only a mobile number.</li>
 * </ul>
 *
 * <p>
 * Switch off with {@code app.schema-patches.enabled=false} if the database user
 * may not alter tables; then run the SQL file by hand.
 */
@Component
public class SchemaPatchRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(SchemaPatchRunner.class);

    static final List<String> PATCHES = List.of(
            "ALTER TABLE IF EXISTS application_users ALTER COLUMN email DROP NOT NULL");

    private final DataSource dataSource;
    private final boolean enabled;

    public SchemaPatchRunner(DataSource dataSource,
                             @Value("${app.schema-patches.enabled:true}") boolean enabled) {
        this.dataSource = dataSource;
        this.enabled = enabled;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!enabled) {
            return;
        }
        try (Connection connection = dataSource.getConnection()) {
            String product = connection.getMetaData().getDatabaseProductName();
            if (product == null || !product.toLowerCase().contains("postgresql")) {
                return;
            }
            try (Statement statement = connection.createStatement()) {
                for (String sql : PATCHES) {
                    statement.execute(sql);
                }
            }
            if (!connection.getAutoCommit()) {
                connection.commit(); // the pool runs with auto-commit off
            }
            log.info("Schema patches applied: {}", PATCHES);
        } catch (Exception e) {
            log.error("Could not apply schema patches {}. Phone-only sign-up will fail until they are run by hand "
                    + "(see make_application_user_email_optional.sql). Cause: {}", PATCHES, e.getMessage());
        }
    }
}
