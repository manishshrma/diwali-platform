package com.forvmom.core.services;

import com.forvmom.common.dto.request.ExperienceCreateRequestDto;
import com.forvmom.common.dto.request.ExperienceDetailRequestDto;
import com.forvmom.common.dto.response.ExperienceDetailResponseDto;
import com.forvmom.common.dto.response.ExperienceHighlightResponseDto;
import com.forvmom.common.dto.response.ExperienceResponseDto;
import com.forvmom.common.errorhandler.ResourceNotFoundException;
import com.forvmom.core.config.ImageUrlConfig;
import com.forvmom.core.mapper.ExperienceBeanMapper;
import com.forvmom.core.mapper.ExperienceMediaBeanMapper;
import com.forvmom.core.mapper.InclusionPolicyBeanMapper;
import com.forvmom.data.dao.ExperienceDao;
import com.forvmom.data.dao.ExperienceDetailDao;
import com.forvmom.data.dao.ExperienceLocationMapperDao;
import com.forvmom.data.dao.ExperienceLocationPincodeMapperDao;
import com.forvmom.data.dao.ExperienceMediaMapperDao;
import com.forvmom.data.dao.PincodeDao;
import com.forvmom.data.dao.SubCategoryDao;
import com.forvmom.data.entities.Experience;
import com.forvmom.data.entities.ExperienceDetail;
import com.forvmom.data.entities.ExperienceLocationMapper;
import com.forvmom.data.entities.ExperienceLocationPincodeMapper;
import com.forvmom.data.entities.ExperienceMediaMapper;
import com.forvmom.data.entities.Media;
import com.forvmom.data.entities.Pincode;
import com.forvmom.data.entities.SubCategory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * JPA-backed implementation of {@link ExperienceService}, the service that owns
 * the {@link Experience} aggregate and its one-to-one
 * {@link ExperienceDetail} row.
 *
 * <p>
 * An experience is identified publicly by a unique slug and always belongs to a
 * {@link SubCategory}. Creation persists both the experience row and its detail
 * row; updates upsert the detail row.
 *
 * <p>
 * Reads deliberately issue several queries instead of one wide join: the first
 * fetch-joins detail, sub-category and inclusion mappers, and follow-up queries
 * load policy mappers, location/time-slot mappers and media mappers into the
 * same Hibernate session. Splitting them avoids the Cartesian product that a
 * single multi-collection join would produce.
 *
 * <p>
 * Write paths keep the Redis catalog snapshot in step by calling
 * {@code CatalogCacheService} inline: {@code updateExperience},
 * {@code toggleActive} and {@code toggleFeatured} warm the snapshot, while
 * {@code deleteExperience} evicts it, so the asynchronous booking enrichment
 * path never reads stale catalog data.
 */
@Service
public class ExperienceServiceImpl implements ExperienceService {
    private static final Logger logger = LoggerFactory.getLogger(ExperienceServiceImpl.class);

    @Autowired
    private ExperienceDao experienceDao;

    @Autowired
    private ExperienceDetailDao experienceDetailDao;

    @Autowired
    private SubCategoryDao subCategoryDao;

    @Autowired
    private CatalogCacheService catalogCacheService;

    @Autowired
    private ExperienceMediaMapperDao experienceMediaMapperDao;

    @Autowired
    private ImageUrlConfig imageUrlConfig;

    @Autowired
    private ImageFlowCacheService imageFlowCacheService;

    @Autowired
    private ExperienceMediaService experienceMediaService;

    @Autowired
    private ImageVariantService imageVariantService;

    @Autowired
    private PincodeDao pincodeDao;

    @Autowired
    private ExperienceLocationMapperDao experienceLocationMapperDao;

    @Autowired
    private ExperienceLocationPincodeMapperDao experienceLocationPincodeMapperDao;

    /**
     * {@inheritDoc}
     *
     * <p>
     * Persists the experience row and its detail row in the same transaction. Note
     * that no cache warming happens here, since a brand new experience has no
     * location or slot mappings to snapshot yet.
     *
     * @param requestDto the experience attributes, including detail fields and the
     *                   owning sub-category id
     * @return the created experience
     * @throws IllegalArgumentException  if the slug is already in use
     * @throws ResourceNotFoundException if the sub-category does not exist
     */
    @Override
    @Transactional
    public ExperienceResponseDto createExperience(ExperienceCreateRequestDto requestDto) {
        if (experienceDao.existsBySlug(requestDto.getSlug())) {
            throw new IllegalArgumentException("Experience with slug '" + requestDto.getSlug() + "' already exists");
        }

        SubCategory subCategory = subCategoryDao.findById(requestDto.getSubCategoryId());
        if (subCategory == null) {
            throw new ResourceNotFoundException("SubCategory not found with id " + requestDto.getSubCategoryId());
        }

        // Save basic experience row
        Experience experience = new Experience();
        ExperienceBeanMapper.mapCreateDtoToEntity(requestDto, experience);
        experience.setSubCategory(subCategory);
        Experience saved = experienceDao.save(experience);

        // Save detail row (always created with the experience)
        ExperienceDetail detail = new ExperienceDetail();
        ExperienceBeanMapper.mapCreateDtoToDetail(requestDto, detail);
        detail.setExperience(saved);
        ExperienceDetail savedDetail = experienceDetailDao.save(detail);
        saved.setDetail(savedDetail);
        imageFlowCacheService.evictExperienceLists();

        return ExperienceBeanMapper.mapEntityToDto(saved, true);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * The slug uniqueness check runs only when the slug changes, and the
     * sub-category is re-resolved only when a different id is supplied. The detail
     * row is upserted: inserted when missing, updated otherwise. Finally the Redis
     * catalog snapshot is warmed inline so booking enrichment sees the new values.
     *
     * @param id         the experience identifier
     * @param requestDto the new experience and detail attributes
     * @return the updated experience
     * @throws ResourceNotFoundException if the experience or the new sub-category
     *                                   does not exist
     * @throws IllegalArgumentException  if the new slug is already in use
     */
    @Override
    @Transactional
    public ExperienceResponseDto updateExperience(Long id, ExperienceCreateRequestDto requestDto) {
        Experience existing = experienceDao.findByIdWithDetail(id);
        if (existing == null) {
            throw new ResourceNotFoundException("Experience not found with id " + id);
        }

        if (!existing.getSlug().equals(requestDto.getSlug()) &&
                experienceDao.existsBySlug(requestDto.getSlug())) {
            throw new IllegalArgumentException("Experience with slug '" + requestDto.getSlug() + "' already exists");
        }

        if (!existing.getSubCategory().getId().equals(requestDto.getSubCategoryId())) {
            SubCategory subCategory = subCategoryDao.findById(requestDto.getSubCategoryId());
            if (subCategory == null) {
                throw new ResourceNotFoundException("SubCategory not found with id " + requestDto.getSubCategoryId());
            }
            existing.setSubCategory(subCategory);
        }

        // Update basic fields
        ExperienceBeanMapper.mapCreateDtoToEntity(requestDto, existing);
        Experience updated = experienceDao.update(existing);

        // Upsert detail
        ExperienceDetail detail = updated.getDetail();
        if (detail == null) {
            detail = new ExperienceDetail();
            detail.setExperience(updated);
        }
        ExperienceBeanMapper.mapCreateDtoToDetail(requestDto, detail);
        ExperienceDetail savedDetail = (detail.getId() == null)
                ? experienceDetailDao.save(detail)
                : experienceDetailDao.update(detail);
        updated.setDetail(savedDetail);

        catalogCacheService.warmExperienceCache(updated);
        imageFlowCacheService.evictExperienceDetail(id);
        imageFlowCacheService.evictExperienceLists();

        return ExperienceBeanMapper.mapEntityToDto(updated, true);
    }

    /*
     * Your current approach with 2 queries is actually quite good:
     * Query 1: Fetches Experience + Detail + SubCategory + InclusionMappers (with
     * JOIN FETCH)
     * Query 2: Fetches PolicyMappers separately (avoids Cartesian product with
     * inclusions)
     * This avoids the multiplied result set problem that would occur if you joined
     * both collections in one query.
     */
    /**
     * {@inheritDoc}
     *
     * <p>
     * Loads the full experience view with four queries (detail plus inclusions,
     * then policies, then locations/time slots, then media gallery), letting
     * Hibernate merge the extra collections into the already-managed entity.
     *
     * @param id the experience identifier
     * @return the experience with inclusions, cancellation policies and locations
     * @throws ResourceNotFoundException if no experience exists with the given id
     */
    @Override
    @Transactional(readOnly = true)
    public ExperienceResponseDto getById(Long id) {
        ExperienceResponseDto cached = imageFlowCacheService.getExperienceDetail(id);
        if (cached != null) {
            logger.info("Cache hit: experience detail key exp:detail:{}:v2", id);
            return cached;
        }
        logger.info("Cache miss: experience detail key exp:detail:{}:v2; loading from DB", id);

        // Query 1: experience + detail + subCategory + inclusionMappers (JOIN FETCH)
        Experience experience = experienceDao.findByIdWithDetail(id);
        if (experience == null) {
            throw new ResourceNotFoundException("Experience not found with id " + id);
        }
        // Query 2: policyMappers (Hibernate merges into same session entity)
        experienceDao.findByIdWithPolicies(id);
        // Query 3: locationMappers + location + timeslotMappers + timeSlot
        experienceDao.findByIdWithLocations(id);

        ExperienceResponseDto dto = ExperienceBeanMapper.mapEntityToDto(experience, true);
        dto.setInclusions(InclusionPolicyBeanMapper.mapInclusionMappers(
                new ArrayList<>(experience.getInclusionMappers())));
        dto.setCancellationPolicies(InclusionPolicyBeanMapper.mapPolicyMappers(
                new ArrayList<>(experience.getPolicyMappers())));
        dto.setLocations(ExperienceBeanMapper.mapLocationMappers(
                new ArrayList<>(experience.getLocationMappers())));
        dto.setMedia(ExperienceMediaBeanMapper.mapEntitiesToDto(
                experienceMediaMapperDao.findByExperienceId(id), imageUrlConfig));
        experienceMediaService.applyVariantUrls(dto.getMedia());
        imageFlowCacheService.putExperienceDetail(id, dto);
        return dto;
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Slug-based counterpart of {@link #getById(Long)}, using the same multi-query
     * loading strategy.
     *
     * @param slug the public experience slug
     * @return the experience with inclusions, cancellation policies and locations
     * @throws ResourceNotFoundException if no experience has that slug
     */
    @Override
    @Transactional(readOnly = true)
    public ExperienceResponseDto getBySlug(String slug) {
        Experience experience = experienceDao.findBySlug(slug);
        if (experience == null) {
            throw new ResourceNotFoundException("Experience not found with slug '" + slug + "'");
        }
        return getById(experience.getId());
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Returns the lightweight highlight projection rather than the full detail
     * view.
     *
     * @return all experiences as highlights, or an empty list when none exist
     */
    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getAll() {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListAll();
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:all:v2:all");
            return cached;
        }
        logger.info("Cache miss: experience list key exp:list:all:v2:all; loading from DB");

        List<Experience> experiences = experienceDao.findAllWithDetail();
        if (experiences == null || experiences.isEmpty())
            return new ArrayList<>();
        List<ExperienceHighlightResponseDto> highlights = experiences.stream()
                .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                .collect(Collectors.toList());
        enrichHighlightsWithCardImages(highlights);
        imageFlowCacheService.putExperienceListAll(highlights);
        return highlights;
    }

    /**
     * {@inheritDoc}
     *
     * @return the active experiences as highlights, or an empty list
     */
    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getAllActive() {
        return getAllActive(null);
    }

    /**
     * {@inheritDoc}
     *
     * @return the active experiences as highlights, or an empty list
     */
    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getAllActive(String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListActive();
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:active:v2:all");
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:active:v2:all; loading from DB");

            List<Experience> experiences = experienceDao.findAllActive();
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListActive(highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Unlike the other list methods, an empty result is reported as an error.
     *
     * @param subCategoryId the sub-category identifier
     * @return the experiences of that sub-category as highlights
     * @throws ResourceNotFoundException if the sub-category has no experiences
     */
    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getBySubCategory(Long subCategoryId) {
        return getBySubCategory(subCategoryId, null);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Unlike the other list methods, an empty result (before pincode filtering)
     * is reported as an error.
     *
     * @param subCategoryId the sub-category identifier
     * @param pincodeCode   the pincode to filter by, or {@code null}/blank for no
     *                      filtering
     * @return the experiences of that sub-category as highlights
     * @throws ResourceNotFoundException if the sub-category has no experiences
     */
    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getBySubCategory(Long subCategoryId, String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListBySubCategory(subCategoryId);
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:subcategory:{}:v2:all", subCategoryId);
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:subcategory:{}:v2:all; loading from DB", subCategoryId);

            List<Experience> experiences = experienceDao.findBySubCategoryId(subCategoryId);
            if (experiences == null || experiences.isEmpty()) {
                throw new ResourceNotFoundException("No experiences found for sub-category id " + subCategoryId);
            }
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListBySubCategory(subCategoryId, highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeatured() {
        return getFeatured(null);
    }

    /**
     * {@inheritDoc}
     *
     * @param pincodeCode the pincode to filter by, or {@code null}/blank for no
     *                     filtering
     * @return the featured experiences as highlights, or an empty list
     */
    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeatured(String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListFeatured();
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:featured:v2:all");
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:featured:v2:all; loading from DB");

            List<Experience> experiences = experienceDao.findFeatured();
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListFeatured(highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    // ---------------------------------------------------------------------------
    // LOCATION + CATEGORY / SUBCATEGORY CATALOG QUERIES (added Oct-2026)
    // See C:\manishshrma\EXPERIENCE-LOCATION-CATEGORY-APIS-PROPOSAL.md
    // Same recipe as getAllActive/getBySubCategory/getFeatured above: cached
    // highlight list -> DAO ordered by displayOrder -> card images ->
    // cache-put -> filterByPincode. Empty DAO result returns an empty list.
    // ---------------------------------------------------------------------------

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getByLocation(Long locationId) {
        return getByLocation(locationId, null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getByLocation(Long locationId, String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListByLocation(locationId);
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:location:{}:v2:all", locationId);
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:location:{}:v2:all; loading from DB", locationId);

            List<Experience> experiences = experienceDao.findActiveByLocationId(locationId);
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListByLocation(locationId, highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeaturedByLocation(Long locationId) {
        return getFeaturedByLocation(locationId, null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeaturedByLocation(Long locationId, String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListFeaturedByLocation(locationId);
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:location:{}:featured:v2:all", locationId);
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:location:{}:featured:v2:all; loading from DB", locationId);

            List<Experience> experiences = experienceDao.findFeaturedByLocationId(locationId);
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListFeaturedByLocation(locationId, highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getByLocationAndCategory(Long locationId, Long categoryId) {
        return getByLocationAndCategory(locationId, categoryId, null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getByLocationAndCategory(Long locationId, Long categoryId, String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListByLocationAndCategory(locationId, categoryId);
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:location:{}:category:{}:v2:all", locationId, categoryId);
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:location:{}:category:{}:v2:all; loading from DB", locationId, categoryId);

            List<Experience> experiences = experienceDao.findActiveByLocationAndCategory(locationId, categoryId);
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListByLocationAndCategory(locationId, categoryId, highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeaturedByLocationAndCategory(Long locationId, Long categoryId) {
        return getFeaturedByLocationAndCategory(locationId, categoryId, null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeaturedByLocationAndCategory(Long locationId, Long categoryId, String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListFeaturedByLocationAndCategory(locationId, categoryId);
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:location:{}:category:{}:featured:v2:all", locationId, categoryId);
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:location:{}:category:{}:featured:v2:all; loading from DB", locationId, categoryId);

            List<Experience> experiences = experienceDao.findFeaturedByLocationAndCategory(locationId, categoryId);
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListFeaturedByLocationAndCategory(locationId, categoryId, highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getByLocationAndSubCategory(Long locationId, Long subCategoryId) {
        return getByLocationAndSubCategory(locationId, subCategoryId, null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getByLocationAndSubCategory(Long locationId, Long subCategoryId, String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListByLocationAndSubCategory(locationId, subCategoryId);
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:location:{}:subcategory:{}:v2:all", locationId, subCategoryId);
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:location:{}:subcategory:{}:v2:all; loading from DB", locationId, subCategoryId);

            List<Experience> experiences = experienceDao.findActiveByLocationAndSubCategory(locationId, subCategoryId);
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListByLocationAndSubCategory(locationId, subCategoryId, highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeaturedByLocationAndSubCategory(Long locationId, Long subCategoryId) {
        return getFeaturedByLocationAndSubCategory(locationId, subCategoryId, null);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ExperienceHighlightResponseDto> getFeaturedByLocationAndSubCategory(Long locationId, Long subCategoryId, String pincodeCode) {
        List<ExperienceHighlightResponseDto> cached = imageFlowCacheService.getExperienceListFeaturedByLocationAndSubCategory(locationId, subCategoryId);
        List<ExperienceHighlightResponseDto> highlights;
        if (cached != null) {
            logger.info("Cache hit: experience list key exp:list:location:{}:subcategory:{}:featured:v2:all", locationId, subCategoryId);
            highlights = cached;
        } else {
            logger.info("Cache miss: experience list key exp:list:location:{}:subcategory:{}:featured:v2:all; loading from DB", locationId, subCategoryId);

            List<Experience> experiences = experienceDao.findFeaturedByLocationAndSubCategory(locationId, subCategoryId);
            if (experiences == null || experiences.isEmpty())
                return new ArrayList<>();
            highlights = experiences.stream()
                    .map(ExperienceBeanMapper::mapEntityToHighlightDto)
                    .collect(Collectors.toList());
            enrichHighlightsWithCardImages(highlights);
            imageFlowCacheService.putExperienceListFeaturedByLocationAndSubCategory(locationId, subCategoryId, highlights);
        }
        return filterByPincode(highlights, pincodeCode);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Soft-deletes the experience (the entity carries {@code @SQLDelete}) and then
     * evicts its Redis catalog snapshot so the removed experience cannot be served
     * from cache.
     *
     * @param id the experience identifier
     * @return {@code true} once the delete has been issued
     * @throws ResourceNotFoundException if no experience exists with the given id
     */
    @Override
    @Transactional
    public boolean deleteExperience(Long id) {
        Experience existing = experienceDao.findById(id);
        if (existing == null) {
            throw new ResourceNotFoundException("Experience not found with id " + id);
        }
        // Soft-delete the experience â€” @SQLDelete on Experience fires UPDATE; the
        // @OneToMany(cascade=ALL, orphanRemoval=true) on inclusionMappers/policyMappers
        // means Hibernate will also remove the junction rows within the same
        // transaction.
        experienceDao.delete(existing);

        // Evict from cache
        catalogCacheService.evictExperience(id);
        imageFlowCacheService.evictExperienceDetail(id);
        imageFlowCacheService.evictExperienceLists();

        return true;
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Flips the active flag and re-warms the catalog snapshot with the new state.
     *
     * @param id the experience identifier
     * @throws ResourceNotFoundException if no experience exists with the given id
     */
    @Override
    @Transactional
    public void toggleActive(Long id) {
        Experience existing = experienceDao.findById(id);
        if (existing == null) {
            throw new ResourceNotFoundException("Experience not found with id " + id);
        }
        existing.setActive(!existing.isActive());
        Experience updated = experienceDao.update(existing);
        catalogCacheService.warmExperienceCache(updated);
        imageFlowCacheService.evictExperienceDetail(id);
        imageFlowCacheService.evictExperienceLists();
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Flips the featured flag and re-warms the catalog snapshot with the new
     * state.
     *
     * @param id the experience identifier
     * @throws ResourceNotFoundException if no experience exists with the given id
     */
    @Override
    @Transactional
    public void toggleFeatured(Long id) {
        Experience existing = experienceDao.findById(id);
        if (existing == null) {
            throw new ResourceNotFoundException("Experience not found with id " + id);
        }
        existing.setIsFeatured(!existing.getIsFeatured());
        Experience updated = experienceDao.update(existing);
        catalogCacheService.warmExperienceCache(updated);
        imageFlowCacheService.evictExperienceDetail(id);
        imageFlowCacheService.evictExperienceLists();
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Inserts the detail row when the experience has none yet, otherwise updates
     * the existing one.
     *
     * @param experienceId the experience identifier
     * @param requestDto   the detail fields to store
     * @return the stored detail
     * @throws ResourceNotFoundException if no experience exists with the given id
     */
    @Override
    @Transactional
    public ExperienceDetailResponseDto upsertDetail(Long experienceId, ExperienceDetailRequestDto requestDto) {
        Experience experience = experienceDao.findById(experienceId);
        if (experience == null) {
            throw new ResourceNotFoundException("Experience not found with id " + experienceId);
        }

        ExperienceDetail detail = experienceDetailDao.findByExperienceId(experienceId);
        if (detail == null) {
            detail = new ExperienceDetail();
            detail.setExperience(experience);
        }

        ExperienceBeanMapper.mapDetailDtoToEntity(requestDto, detail);
        ExperienceDetail saved = (detail.getId() == null)
                ? experienceDetailDao.save(detail)
                : experienceDetailDao.update(detail);
        imageFlowCacheService.evictExperienceDetail(experienceId);
        imageFlowCacheService.evictExperienceLists();

        return ExperienceBeanMapper.mapDetailToDto(saved);
    }

    private void enrichHighlightsWithCardImages(List<ExperienceHighlightResponseDto> highlights) {
        if (highlights == null || highlights.isEmpty()) {
            return;
        }

        Map<Long, ExperienceHighlightResponseDto> highlightsByExperienceId = highlights.stream()
                .filter(dto -> dto.getId() != null)
                .collect(Collectors.toMap(
                        ExperienceHighlightResponseDto::getId,
                        dto -> dto,
                        (left, right) -> left,
                        LinkedHashMap::new));
        if (highlightsByExperienceId.isEmpty()) {
            return;
        }

        List<ExperienceMediaMapper> mediaMappers = experienceMediaMapperDao.findActiveByExperienceIdsOrdered(
                new ArrayList<>(highlightsByExperienceId.keySet()));
        if (mediaMappers.isEmpty()) {
            return;
        }

        Map<Long, ExperienceMediaMapper> selectedByExperienceId = new LinkedHashMap<>();
        for (ExperienceMediaMapper mapper : mediaMappers) {
            if (mapper.getExperience() == null || mapper.getExperience().getId() == null || mapper.getMedia() == null) {
                continue;
            }
            selectedByExperienceId.putIfAbsent(mapper.getExperience().getId(), mapper);
        }
        if (selectedByExperienceId.isEmpty()) {
            return;
        }

        List<Long> mediaIds = selectedByExperienceId.values().stream()
                .map(ExperienceMediaMapper::getMedia)
                .map(Media::getId)
                .collect(Collectors.toList());
        Map<Long, ImageVariantService.VariantUrls> variantUrlsByMediaId = imageVariantService.getUrlsForMediaIds(mediaIds);

        for (Map.Entry<Long, ExperienceMediaMapper> entry : selectedByExperienceId.entrySet()) {
            ExperienceHighlightResponseDto dto = highlightsByExperienceId.get(entry.getKey());
            if (dto == null) {
                continue;
            }

            ExperienceMediaMapper mapper = entry.getValue();
            Media media = mapper.getMedia();
            ImageVariantService.VariantUrls urls = variantUrlsByMediaId.get(media.getId());

            if (urls != null) {
                dto.setHeroUrl(urls.getHeroUrl());
                dto.setThumbnailUrl(urls.getThumbnailUrl());
                dto.setOriginalUrl(urls.getOriginalUrl());
            } else if (media.getStorageFileName() != null) {
                String fallbackUrl = imageUrlConfig.buildPublicUrl(media.getStorageFileName());
                dto.setHeroUrl(fallbackUrl);
                dto.setThumbnailUrl(fallbackUrl);
                dto.setOriginalUrl(fallbackUrl);
            }

            dto.setImageAltText(mapper.getAltText() != null ? mapper.getAltText() : media.getAltText());
        }
    }

    /**
     * {@inheritDoc}
     *
     * @param experienceId the experience identifier
     * @return the detail row of that experience
     * @throws ResourceNotFoundException if the experience has no detail row
     */
    @Override
    @Transactional(readOnly = true)
    public ExperienceDetailResponseDto getDetail(Long experienceId) {
        ExperienceDetail detail = experienceDetailDao.findByExperienceId(experienceId);
        if (detail == null) {
            throw new ResourceNotFoundException("No detail found for experience id " + experienceId);
        }
        return ExperienceBeanMapper.mapDetailToDto(detail);
    }

    /**
     * Filters a highlight list down to experiences serviceable at a pincode.
     *
     * <p>
     * Returns a new list (never mutates {@code highlights}, which may be a
     * cached instance shared across requests). When {@code pincodeCode} is
     * {@code null}/blank the input list is returned unchanged.
     *
     * @param highlights  the highlight list to filter (cached or freshly loaded)
     * @param pincodeCode the pincode to filter by, or {@code null}/blank for no
     *                    filtering
     * @return the filtered list
     * @throws ResourceNotFoundException if the pincode is unknown
     */
    private List<ExperienceHighlightResponseDto> filterByPincode(List<ExperienceHighlightResponseDto> highlights,
                                                                  String pincodeCode) {
        if (pincodeCode == null || pincodeCode.trim().isEmpty() || highlights.isEmpty()) {
            return highlights;
        }

        Pincode pincode = pincodeDao.findByPincodeCode(pincodeCode.trim());
        if (pincode == null) {
            throw new ResourceNotFoundException("Pincode not found: " + pincodeCode);
        }

        List<Long> serviceableIds = experienceLocationPincodeMapperDao
                .findServiceableExperienceIds(pincode.getLocation().getId(), pincode.getId());
        Set<Long> serviceableIdSet = new HashSet<>(serviceableIds);

        return highlights.stream()
                .filter(h -> serviceableIdSet.contains(h.getId()))
                .collect(Collectors.toList());
    }

    /**
     * {@inheritDoc}
     *
     * @param experienceId the experience identifier
     * @param pincodeCode  the pincode code entered by the customer
     * @return {@code true} when the experience is serviceable at the pincode
     * @throws ResourceNotFoundException if the experience or pincode is unknown
     */
    @Override
    @Transactional(readOnly = true)
    public boolean isExperienceServiceableAtPincode(Long experienceId, String pincodeCode) {
        if (experienceDao.findById(experienceId) == null) {
            throw new ResourceNotFoundException("Experience not found with id " + experienceId);
        }
        Pincode pincode = pincodeDao.findByPincodeCode(pincodeCode);
        if (pincode == null) {
            throw new ResourceNotFoundException("Pincode not found: " + pincodeCode);
        }

        ExperienceLocationMapper mapper = experienceLocationMapperDao
                .findByExperienceIdAndLocationId(experienceId, pincode.getLocation().getId());
        if (mapper == null || !Boolean.TRUE.equals(mapper.getIsActive())) {
            return false;
        }

        List<ExperienceLocationPincodeMapper> restrictions = experienceLocationPincodeMapperDao
                .findByMapperId(mapper.getId());
        if (restrictions.isEmpty()) {
            // Unrestricted: serviceable everywhere in the attached location.
            return true;
        }

        boolean matched = restrictions.stream()
                .anyMatch(r -> Boolean.TRUE.equals(r.getIsActive())
                        && r.getPincode().getId().equals(pincode.getId()));

        if ("BLACKLIST".equalsIgnoreCase(mapper.getPincodeRestrictionType())
                || "EXCLUDE".equalsIgnoreCase(mapper.getPincodeRestrictionType())) {
            // Reverse mode: selected pincodes are DISABLED
            return !matched;
        }

        // Whitelist mode: only selected pincodes are ALLOWED
        return matched;
    }
}
