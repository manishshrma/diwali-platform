package com.forvmom.core.seeder;

import com.forvmom.data.dao.auth.AuthUserDao;
import com.forvmom.data.dao.auth.RoleDao;
import com.forvmom.data.entities.auth.Role;
import com.forvmom.security.dto.RegisterRequestDto;
import com.forvmom.security.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Bootstraps the first {@code SUPER_ADMIN} account on application startup.
 *
 * <p>
 * This is the only way the first super admin is created; the public
 * {@code /auth/register} endpoint can only create customers. Credentials come
 * from configuration ({@code app.bootstrap.super-admin.*}, normally the
 * {@code SUPER_ADMIN_EMAIL} and {@code SUPER_ADMIN_PASSWORD} environment
 * variables). There is no built-in password: if none is configured the seeder
 * does nothing.
 *
 * <p>
 * The seeder is idempotent and never touches an account that already exists,
 * so changing {@code SUPER_ADMIN_PASSWORD} later does <strong>not</strong>
 * change the stored password.
 *
 * <p>
 * Seeding failures are logged rather than rethrown: a broken seed must not
 * prevent the service from starting and serving read traffic.
 */
@Component
public class SuperAdminSeeder implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(SuperAdminSeeder.class);

    static final int MIN_PASSWORD_LENGTH = 8;

    private final AuthService authService;
    private final RoleDao roleDao;
    private final AuthUserDao authUserDao;
    private final String superAdminEmail;
    private final String superAdminPassword;

    public SuperAdminSeeder(AuthService authService, RoleDao roleDao, AuthUserDao authUserDao,
            @Value("${app.bootstrap.super-admin.email:}") String superAdminEmail,
            @Value("${app.bootstrap.super-admin.password:}") String superAdminPassword) {
        this.authService = authService;
        this.roleDao = roleDao;
        this.authUserDao = authUserDao;
        this.superAdminEmail = superAdminEmail == null ? "" : superAdminEmail.trim().toLowerCase();
        this.superAdminPassword = superAdminPassword == null ? "" : superAdminPassword;
    }

    /**
     * Creates the configured {@code SUPER_ADMIN} user if it does not already
     * exist and a usable password is configured.
     *
     * @param args standard command-line arguments (unused)
     */
    @Override
    @Transactional
    public void run(String... args) {
        if (superAdminEmail.isBlank()) {
            logger.warn("Super admin bootstrap skipped: SUPER_ADMIN_EMAIL is not set.");
            return;
        }
        if (authUserDao.existsByUsername(superAdminEmail)) {
            logger.info("SUPER_ADMIN user already exists: {}", superAdminEmail);
            return;
        }
        if (superAdminPassword.length() < MIN_PASSWORD_LENGTH) {
            logger.warn("Super admin bootstrap skipped: SUPER_ADMIN_PASSWORD is not set or shorter than {} "
                    + "characters. Set it and restart to create {}.", MIN_PASSWORD_LENGTH, superAdminEmail);
            return;
        }

        try {
            Role superAdminRole = roleDao.findByNameIgnoreCase("SUPER_ADMIN")
                    .orElseThrow(() -> new IllegalStateException("Role SUPER_ADMIN is not seeded"));

            RegisterRequestDto request = new RegisterRequestDto();
            request.setEmail(superAdminEmail);
            request.setPassword(superAdminPassword);
            request.setFullName("Super Administrator");
            request.setRoleId(superAdminRole.getId());
            request.setPreferredCity("Headquarters");

            logger.info("Creating SUPER_ADMIN user: {}", superAdminEmail);
            authService.createAccount(request);
            logger.info("SUPER_ADMIN user created successfully.");
        } catch (Exception e) {
            logger.error("Failed to create SUPER_ADMIN user: {}", e.getMessage());
        }
    }
}
