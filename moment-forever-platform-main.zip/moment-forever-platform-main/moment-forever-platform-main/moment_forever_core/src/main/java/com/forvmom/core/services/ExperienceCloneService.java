package com.forvmom.core.services;

import com.forvmom.common.dto.request.ExperienceCloneRequestDto;
import com.forvmom.common.dto.response.ExperienceCloneResponseDto;
import com.forvmom.common.errorhandler.ConflictException;
import com.forvmom.common.errorhandler.ResourceNotFoundException;
import com.forvmom.core.mapper.ExperienceBeanMapper;
import com.forvmom.data.dao.ExperienceDao;
import com.forvmom.data.dao.SubCategoryDao;
import com.forvmom.data.entities.Experience;
import com.forvmom.data.entities.ExperienceAddonMapper;
import com.forvmom.data.entities.ExperienceCancellationPolicyMapper;
import com.forvmom.data.entities.ExperienceCouponMapper;
import com.forvmom.data.entities.ExperienceDetail;
import com.forvmom.data.entities.ExperienceInclusionMapper;
import com.forvmom.data.entities.ExperienceLocationMapper;
import com.forvmom.data.entities.ExperienceLocationPincodeMapper;
import com.forvmom.data.entities.ExperienceMediaMapper;
import com.forvmom.data.entities.ExperienceTimeSlotMapper;
import com.forvmom.data.entities.SubCategory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Pattern;

/**
 * Copies an experience together with everything an admin configured on it, so
 * a similar product can be set up by editing a copy instead of entering it
 * again from scratch.
 *
 * <p>
 * <b>Copied</b> (new rows with new ids, all in one transaction):
 * <ul>
 * <li>the experience row and its detail row;</li>
 * <li>inclusion and cancellation-policy links, with their display order;</li>
 * <li>add-on links, with the per-experience price and free flag;</li>
 * <li>coupon links;</li>
 * <li>gallery links, with display order, primary flag and alt text;</li>
 * <li>every city link, with its price, validity dates, pincode rule mode, the
 * pincode list and the time-slot links (slot price, capacity, validity).</li>
 * </ul>
 *
 * <p>
 * <b>Shared, not duplicated:</b> the master records those links point to —
 * inclusions, policies, add-ons, coupons, images (and their stored files),
 * locations, pincodes and time slots. They are reusable by design. Editing or
 * detaching anything on the copy only touches the copy's link rows.
 *
 * <p>
 * <b>Not copied:</b> reviews, which belong to the original's customers, and
 * slot inventory, whose booked counts belong to the original's bookings.
 *
 * <p>
 * The copy starts <b>inactive and not featured</b> unless the request says
 * otherwise, so customers do not see it before an admin has reviewed it. Any
 * failure rolls the whole copy back.
 */
@Service
public class ExperienceCloneService {

    private static final Logger logger = LoggerFactory.getLogger(ExperienceCloneService.class);

    static final String NAME_SUFFIX = " (Copy)";
    static final String SLUG_SUFFIX = "-copy";
    /** How many "-copy", "-copy-2" … candidates to try before giving up. */
    static final int MAX_SLUG_ATTEMPTS = 50;

    private static final int NAME_MAX_LENGTH = 255;
    private static final int SLUG_MAX_LENGTH = 220;

    /** Matches a "-copy" or "-copy-7" ending left by an earlier clone. */
    private static final Pattern EARLIER_COPY_SLUG_SUFFIX = Pattern.compile("-copy(-\\d+)?$");

    private final ExperienceDao experienceDao;
    private final SubCategoryDao subCategoryDao;
    private final CatalogCacheService catalogCacheService;
    private final ImageFlowCacheService imageFlowCacheService;

    public ExperienceCloneService(ExperienceDao experienceDao,
            SubCategoryDao subCategoryDao,
            CatalogCacheService catalogCacheService,
            ImageFlowCacheService imageFlowCacheService) {
        this.experienceDao = experienceDao;
        this.subCategoryDao = subCategoryDao;
        this.catalogCacheService = catalogCacheService;
        this.imageFlowCacheService = imageFlowCacheService;
    }

    /**
     * Creates a full copy of an experience.
     *
     * @param sourceId id of the experience to copy; inactive experiences can be
     *                 copied too
     * @param request  optional name, slug, sub-category and visibility for the
     *                 copy; {@code null} uses every default
     * @return the new experience plus how many linked rows were copied
     * @throws ResourceNotFoundException if the source experience or the requested
     *                                   sub-category does not exist
     * @throws IllegalArgumentException  if the requested slug is already used
     * @throws ConflictException         if no free "-copy" slug could be found
     */
    @Transactional
    public ExperienceCloneResponseDto cloneExperience(Long sourceId, ExperienceCloneRequestDto request) {
        ExperienceCloneRequestDto options = request != null ? request : new ExperienceCloneRequestDto();

        Experience source = loadSourceGraph(sourceId);
        SubCategory subCategory = resolveSubCategory(source, options.getSubCategoryId());
        String slug = resolveSlug(source, options.getSlug());
        String name = resolveName(source, options.getName());

        ExperienceCloneResponseDto.CopiedParts copied = new ExperienceCloneResponseDto.CopiedParts();
        Experience copy = copyExperienceRow(source, name, slug, subCategory, options);
        copyDetail(source, copy, copied);
        copyInclusions(source, copy, copied);
        copyPolicies(source, copy, copied);
        copyAddons(source, copy, copied);
        copyCoupons(source, copy, copied);
        copyMedia(source, copy, copied);
        copyLocations(source, copy, copied);

        // One persist: Experience cascades to the detail and every link
        // collection, and each city link cascades to its pincodes and slots.
        experienceDao.save(copy);

        refreshCaches(copy);
        logger.info("Cloned experience {} into {} (slug '{}'): {} cities, {} time slots, {} images",
                sourceId, copy.getId(), slug, copied.getLocations(), copied.getTimeSlots(), copied.getMedia());

        ExperienceCloneResponseDto response = new ExperienceCloneResponseDto();
        response.setSourceExperienceId(sourceId);
        response.setExperience(ExperienceBeanMapper.mapEntityToDto(copy, true));
        response.setCopied(copied);
        return response;
    }

    // ── Loading ───────────────────────────────────────────────────────────────

    /**
     * Loads the source with the same split queries the detail endpoint uses, so
     * Hibernate merges them into one managed instance without a Cartesian
     * product. Add-on, coupon, media and pincode collections load lazily inside
     * this transaction.
     */
    private Experience loadSourceGraph(Long sourceId) {
        Experience source = experienceDao.findByIdWithDetail(sourceId);
        if (source == null) {
            throw new ResourceNotFoundException("Experience not found with id " + sourceId);
        }
        experienceDao.findByIdWithPolicies(sourceId);
        experienceDao.findByIdWithLocations(sourceId);
        return source;
    }

    private SubCategory resolveSubCategory(Experience source, Long requestedId) {
        SubCategory current = source.getSubCategory();
        if (requestedId == null || (current != null && requestedId.equals(current.getId()))) {
            return current;
        }
        SubCategory requested = subCategoryDao.findById(requestedId);
        if (requested == null) {
            throw new ResourceNotFoundException("SubCategory not found with id " + requestedId);
        }
        return requested;
    }

    // ── Name and slug ─────────────────────────────────────────────────────────

    String resolveSlug(Experience source, String requested) {
        if (StringUtils.hasText(requested)) {
            String slug = requested.trim();
            if (experienceDao.existsBySlugIncludingDeleted(slug)) {
                throw new IllegalArgumentException("Experience with slug '" + slug + "' already exists");
            }
            return slug;
        }

        // Cloning a copy gives "x-copy-2", not "x-copy-copy".
        String root = EARLIER_COPY_SLUG_SUFFIX.matcher(source.getSlug()).replaceFirst("");
        int room = SLUG_MAX_LENGTH - SLUG_SUFFIX.length() - ("-" + MAX_SLUG_ATTEMPTS).length();
        root = truncate(root, room).replaceAll("-+$", "");
        if (root.isEmpty()) {
            root = "experience";
        }
        String base = root + SLUG_SUFFIX;

        for (int attempt = 1; attempt <= MAX_SLUG_ATTEMPTS; attempt++) {
            String candidate = attempt == 1 ? base : base + "-" + attempt;
            if (!experienceDao.existsBySlugIncludingDeleted(candidate)) {
                return candidate;
            }
        }
        throw new ConflictException("No free slug found for a copy of '" + source.getSlug()
                + "'. Send a slug in the request.");
    }

    String resolveName(Experience source, String requested) {
        if (StringUtils.hasText(requested)) {
            return requested.trim();
        }
        String root = source.getName() == null ? "" : source.getName().trim();
        if (root.endsWith(NAME_SUFFIX)) {
            root = root.substring(0, root.length() - NAME_SUFFIX.length()).trim();
        }
        return truncate(root, NAME_MAX_LENGTH - NAME_SUFFIX.length()) + NAME_SUFFIX;
    }

    // ── Copying ───────────────────────────────────────────────────────────────

    private Experience copyExperienceRow(Experience source, String name, String slug,
            SubCategory subCategory, ExperienceCloneRequestDto options) {
        Experience copy = new Experience();
        copy.setName(name);
        copy.setSlug(slug);
        copy.setTagName(source.getTagName());
        copy.setBasePrice(source.getBasePrice());
        copy.setDisplayOrder(source.getDisplayOrder());
        copy.setSubCategory(subCategory);
        copy.setActive(Boolean.TRUE.equals(options.getIsActive()));
        copy.setIsFeatured(Boolean.TRUE.equals(options.getIsFeatured()));
        return copy;
    }

    private void copyDetail(Experience source, Experience copy, ExperienceCloneResponseDto.CopiedParts copied) {
        ExperienceDetail from = source.getDetail();
        if (from == null) {
            return;
        }
        ExperienceDetail to = new ExperienceDetail();
        to.setShortDescription(from.getShortDescription());
        to.setDescription(from.getDescription());
        to.setDurationMinutes(from.getDurationMinutes());
        to.setMaxCapacity(from.getMaxCapacity());
        to.setMinAge(from.getMinAge());
        to.setCompletionTime(from.getCompletionTime());
        to.setMinHours(from.getMinHours());
        to.setTermsConditions(from.getTermsConditions());
        to.setWhatToBring(from.getWhatToBring());
        to.setIsActive(from.getIsActive());
        copy.setDetail(to);
        copied.setDetail(true);
    }

    private void copyInclusions(Experience source, Experience copy, ExperienceCloneResponseDto.CopiedParts copied) {
        for (ExperienceInclusionMapper from : inIdOrder(source.getInclusionMappers(), ExperienceInclusionMapper::getId)) {
            if (from.isDeleted()) {
                continue;
            }
            ExperienceInclusionMapper to = new ExperienceInclusionMapper();
            to.setInclusion(from.getInclusion());
            to.setDisplayOrder(from.getDisplayOrder());
            to.setIsActive(from.getIsActive());
            copy.addInclusionMapper(to);
            copied.setInclusions(copied.getInclusions() + 1);
        }
    }

    private void copyPolicies(Experience source, Experience copy, ExperienceCloneResponseDto.CopiedParts copied) {
        for (ExperienceCancellationPolicyMapper from : inIdOrder(source.getPolicyMappers(),
                ExperienceCancellationPolicyMapper::getId)) {
            if (from.isDeleted()) {
                continue;
            }
            ExperienceCancellationPolicyMapper to = new ExperienceCancellationPolicyMapper();
            to.setPolicy(from.getPolicy());
            to.setDisplayOrder(from.getDisplayOrder());
            to.setIsActive(from.getIsActive());
            copy.addPolicyMapper(to);
            copied.setCancellationPolicies(copied.getCancellationPolicies() + 1);
        }
    }

    private void copyAddons(Experience source, Experience copy, ExperienceCloneResponseDto.CopiedParts copied) {
        for (ExperienceAddonMapper from : inIdOrder(source.getAddonMappers(), ExperienceAddonMapper::getId)) {
            if (from.isDeleted()) {
                continue;
            }
            ExperienceAddonMapper to = new ExperienceAddonMapper();
            to.setAddon(from.getAddon());
            to.setPriceOverride(from.getPriceOverride());
            to.setIsFree(from.getIsFree());
            to.setIsActive(from.getIsActive());
            copy.addAddonMapper(to);
            copied.setAddons(copied.getAddons() + 1);
        }
    }

    private void copyCoupons(Experience source, Experience copy, ExperienceCloneResponseDto.CopiedParts copied) {
        for (ExperienceCouponMapper from : inIdOrder(source.getCouponMappers(), ExperienceCouponMapper::getId)) {
            if (from.isDeleted()) {
                continue;
            }
            ExperienceCouponMapper to = new ExperienceCouponMapper();
            to.setCoupon(from.getCoupon());
            to.setIsActive(from.getIsActive());
            copy.addCouponMapper(to);
            copied.setCoupons(copied.getCoupons() + 1);
        }
    }

    private void copyMedia(Experience source, Experience copy, ExperienceCloneResponseDto.CopiedParts copied) {
        for (ExperienceMediaMapper from : inIdOrder(source.getMediaMappers(), ExperienceMediaMapper::getId)) {
            if (from.isDeleted()) {
                continue;
            }
            ExperienceMediaMapper to = new ExperienceMediaMapper();
            to.setMedia(from.getMedia());
            to.setDisplayOrder(from.getDisplayOrder());
            to.setIsPrimary(from.getIsPrimary());
            to.setAltText(from.getAltText());
            to.setIsActive(from.getIsActive());
            copy.addMediaMapper(to);
            copied.setMedia(copied.getMedia() + 1);
        }
    }

    private void copyLocations(Experience source, Experience copy, ExperienceCloneResponseDto.CopiedParts copied) {
        for (ExperienceLocationMapper from : inIdOrder(source.getLocationMappers(), ExperienceLocationMapper::getId)) {
            if (from.isDeleted()) {
                continue;
            }
            ExperienceLocationMapper to = new ExperienceLocationMapper();
            to.setLocation(from.getLocation());
            to.setPriceOverride(from.getPriceOverride());
            to.setIsActive(from.getIsActive());
            to.setValidFrom(from.getValidFrom());
            to.setValidTo(from.getValidTo());
            to.setPincodeRestrictionType(from.getPincodeRestrictionType());

            for (ExperienceLocationPincodeMapper pincode : inIdOrder(from.getPincodeMappers(),
                    ExperienceLocationPincodeMapper::getId)) {
                if (pincode.isDeleted()) {
                    continue;
                }
                ExperienceLocationPincodeMapper pincodeCopy = new ExperienceLocationPincodeMapper();
                pincodeCopy.setPincode(pincode.getPincode());
                pincodeCopy.setIsActive(pincode.getIsActive());
                to.addPincodeMapper(pincodeCopy);
                copied.setPincodes(copied.getPincodes() + 1);
            }

            for (ExperienceTimeSlotMapper slot : inIdOrder(from.getTimeSlotMappers(), ExperienceTimeSlotMapper::getId)) {
                if (Boolean.TRUE.equals(slot.getDeleted())) {
                    continue;
                }
                ExperienceTimeSlotMapper slotCopy = new ExperienceTimeSlotMapper();
                slotCopy.setTimeSlot(slot.getTimeSlot());
                slotCopy.setPriceOverride(slot.getPriceOverride());
                slotCopy.setMaxCapacity(slot.getMaxCapacity());
                slotCopy.setIsActive(slot.getIsActive());
                slotCopy.setValidFrom(slot.getValidFrom());
                slotCopy.setValidTo(slot.getValidTo());
                to.addTimeSlotMapper(slotCopy);
                copied.setTimeSlots(copied.getTimeSlots() + 1);
            }

            copy.addLocationMapper(to);
            copied.setLocations(copied.getLocations() + 1);
        }
    }

    // ── Cache ─────────────────────────────────────────────────────────────────

    /**
     * Drops the cached experience lists so the copy shows up in the admin list,
     * then warms the booking snapshots the attach flows normally warm. Redis is
     * an optimisation here: booking enrichment falls back to the database on a
     * miss, so a Redis failure must not undo a successful copy.
     */
    private void refreshCaches(Experience copy) {
        try {
            imageFlowCacheService.evictExperienceLists();
        } catch (RuntimeException e) {
            logger.warn("Experience {} cloned, but evicting the cached lists failed: {}", copy.getId(), e.getMessage());
        }
        try {
            catalogCacheService.warmExperienceCache(copy);
            for (ExperienceLocationMapper location : copy.getLocationMappers()) {
                catalogCacheService.warmLocationCache(location);
                for (ExperienceTimeSlotMapper slot : location.getTimeSlotMappers()) {
                    catalogCacheService.warmSlotCache(slot);
                }
            }
            for (ExperienceAddonMapper addon : copy.getAddonMappers()) {
                catalogCacheService.warmAddonCache(addon);
            }
        } catch (RuntimeException e) {
            logger.warn("Experience {} cloned, but warming the booking cache failed; "
                    + "bookings will read from the database: {}", copy.getId(), e.getMessage());
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Copies rows in their original order so the new ids follow it too. */
    private static <T> List<T> inIdOrder(Collection<T> rows, Function<T, Long> id) {
        if (rows == null || rows.isEmpty()) {
            return List.of();
        }
        List<T> sorted = new ArrayList<>(rows);
        sorted.sort(Comparator.comparing(id, Comparator.nullsLast(Comparator.naturalOrder())));
        return sorted;
    }

    private static String truncate(String value, int maxLength) {
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }
}
