package com.forvmom.core.controller.pub;

import com.forvmom.common.response.ApiResponse;
import com.forvmom.common.response.ResponseUtil;
import com.forvmom.common.utils.AppConstants;
import com.forvmom.core.services.ImageService;
import com.forvmom.core.services.MediaService;
import com.forvmom.store.dto.ImageResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Read-only image metadata and streaming endpoints for the storefront.
 *
 * <p>
 * Mapped under {@code /public/images} and reachable without authentication, so
 * it exposes reads only. Upload, metadata update, delete and the batch ZIP
 * download are admin operations and live in {@code ImageControllerAdmin} under
 * {@code /admin/images}.
 *
 * <p>
 * Binaries live in MongoDB GridFS while a SQL {@code Media} row holds the
 * metadata; the SQL row's {@code filePath} is the GridFS id used for retrieval.
 * Downloads stream the stored {@link Resource} back with the content type
 * recorded in GridFS, falling back to {@code application/octet-stream}, and use
 * {@code Content-Disposition: inline} so browsers render rather than save the
 * image.
 */
@RestController
@RequestMapping("/public/images")
@Tag(name = "Public Image API", description = "Read and stream images (uploads and changes are under /admin/images)")
public class ImageController {

    @Autowired
    private ImageService imageService;

    @Autowired
    private MediaService mediaService;

    // ── Read ──────────────────────────────────────────────────────────────────

    /**
     * Lists all active media records with their public URLs.
     *
     * @return {@code 200 OK} wrapping the list of {@link ImageResponse}
     */
    @GetMapping
    @Operation(summary = "List All Images", description = "Returns all active media records with public URLs")
    public ResponseEntity<ApiResponse<List<ImageResponse>>> getAllImages() {
        List<ImageResponse> response = mediaService.getAllMedia();
        return ResponseEntity.ok(ResponseUtil.buildOkResponse(response, AppConstants.MSG_FETCHED));
    }

    /**
     * Returns the metadata of a single media record.
     *
     * @param id SQL identifier of the media record
     * @return {@code 200 OK} wrapping the {@link ImageResponse}
     */
    @GetMapping("/{id}")
    @Operation(summary = "Get Image by SQL ID")
    public ResponseEntity<ApiResponse<ImageResponse>> getImageById(@PathVariable Long id) {
        ImageResponse response = mediaService.getMediaById(id);
        return ResponseEntity.ok(ResponseUtil.buildOkResponse(response, AppConstants.MSG_FETCHED));
    }

    // ── Download (single) ─────────────────────────────────────────────────────

    /**
     * Streams an image identified by its SQL media id.
     *
     * <p>
     * The GridFS id is read from the media record's {@code filePath}, and the
     * response is marked {@code inline} so the browser displays it.
     *
     * @param id SQL identifier of the media record
     * @return {@code 200 OK} with the image bytes as a {@link Resource}
     * @throws IOException if the resource length cannot be determined
     */
    @GetMapping("/{id}/download")
    @Operation(summary = "Download Image by SQL ID", description = "Looks up the GridFS filePath from the Media SQL record and streams the file")
    public ResponseEntity<Resource> downloadImage(@PathVariable Long id) throws IOException {
        ImageResponse media = mediaService.getMediaById(id);
        String gridFsId = media.getFilePath();

        Resource resource = imageService.downloadImage(gridFsId);
        String contentType = imageService.getContentType(gridFsId)
                .orElse(MediaType.APPLICATION_OCTET_STREAM_VALUE);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + resource.getFilename() + "\"")
                .contentType(MediaType.parseMediaType(contentType))
                .contentLength(resource.contentLength())
                .body(resource);
    }

    /**
     * Streams an image addressed by its cache-busting {@code storageFileName}.
     *
     * <p>
     * This is the URL form embedded in catalog responses: because the name carries
     * an upload timestamp, a replaced image gets a different path and caches do not
     * serve the stale binary.
     *
     * @param storageFileName generated unique file name of the stored image
     * @return {@code 200 OK} with the image bytes as a {@link Resource}
     * @throws IOException if the resource length cannot be determined
     */
    @GetMapping("/fetch/{storageFileName}")
    @Operation(summary = "Fetch Image by storageFileName", description = "Looks up the GridFS filePath from the Media SQL record and streams the file based on cache busted storageFileName")
    public ResponseEntity<Resource> downloadImageWithCacheBust(
            @PathVariable String storageFileName,
            @RequestHeader(value = HttpHeaders.IF_NONE_MATCH, required = false) String ifNoneMatch) throws IOException {
        String eTag = "\"" + storageFileName + "\"";
        CacheControl cacheControl = CacheControl.maxAge(365, TimeUnit.DAYS)
                .cachePublic()
                .immutable();

        if (eTag.equals(ifNoneMatch)) {
            return ResponseEntity.status(HttpStatus.NOT_MODIFIED)
                    .eTag(eTag)
                    .cacheControl(cacheControl)
                    .build();
        }

        String gridFsId = mediaService.getMediaByStorageFileName(storageFileName);
        Resource resource = imageService.downloadImage(gridFsId);
        String contentType = imageService.getContentType(gridFsId)
                .orElse(MediaType.APPLICATION_OCTET_STREAM_VALUE);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + resource.getFilename() + "\"")
                .cacheControl(cacheControl)
                .eTag(eTag)
                .contentType(MediaType.parseMediaType(contentType))
                .contentLength(resource.contentLength())
                .body(resource);
    }
}
